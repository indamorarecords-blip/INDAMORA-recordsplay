import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';

// A ticket binds one upload destination to its creator and declared metadata.
// It does not grant download access or replace server-side file validation.
const MAX_BYTES = 50 * 1024 * 1024;
const MIME_TYPES = new Set([
  'audio/mpeg', 'audio/mp4', 'audio/x-m4a', 'audio/wav', 'audio/ogg',
  'video/mp4', 'video/webm', 'video/quicktime',
  'image/jpeg', 'image/png', 'image/webp',
]);
type UploadClaims = { version: 1; id: string; ownerId: string; mime: string; size: number; expiresAt: number };

function signature(payload: string, key: string): Buffer {
  return createHmac('sha256', key).update(payload, 'utf8').digest();
}

function validKey(key: string): boolean { return Buffer.byteLength(key, 'utf8') >= 32; }
function validClaims(value: unknown): value is UploadClaims {
  if (!value || typeof value !== 'object') return false;
  const c = value as Partial<UploadClaims>;
  return c.version === 1 && typeof c.id === 'string' && /^[0-9a-f-]{36}$/.test(c.id) &&
    typeof c.ownerId === 'string' && c.ownerId.length > 0 && c.ownerId.length <= 200 &&
    typeof c.mime === 'string' && MIME_TYPES.has(c.mime) &&
    typeof c.size === 'number' && Number.isSafeInteger(c.size) && c.size > 0 && c.size <= MAX_BYTES &&
    typeof c.expiresAt === 'number' && Number.isSafeInteger(c.expiresAt);
}

export function createUploadTicket(input: { ownerId: string; mime: string; size: number }, key: string, now = Date.now()) {
  if (!validKey(key)) throw new Error('La clé de signature des téléversements doit contenir au moins 32 octets.');
  const claims: UploadClaims = { version: 1, id: randomUUID(), ...input, expiresAt: now + 2 * 60 * 60 * 1000 };
  if (!validClaims(claims)) throw new Error('Métadonnées de téléversement invalides.');
  const payload = Buffer.from(JSON.stringify(claims), 'utf8').toString('base64url');
  return { token: `${payload}.${signature(payload, key).toString('base64url')}`, id: claims.id };
}

export function verifyUploadTicket(token: string, ownerId: string, key: string, now = Date.now()): UploadClaims | null {
  if (!validKey(key) || token.length > 4096) return null;
  const parts = token.split('.');
  if (parts.length !== 2 || !/^[A-Za-z0-9_-]+$/.test(parts[0]) || !/^[A-Za-z0-9_-]+$/.test(parts[1])) return null;
  const actual = Buffer.from(parts[1], 'base64url');
  const expected = signature(parts[0], key);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return null;
  try {
    const claims: unknown = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    if (!validClaims(claims) || claims.ownerId !== ownerId || claims.expiresAt <= now) return null;
    return claims;
  } catch { return null; }
}
