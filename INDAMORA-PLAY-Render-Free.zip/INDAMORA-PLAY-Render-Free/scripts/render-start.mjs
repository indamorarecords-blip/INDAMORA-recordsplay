import { spawn } from 'node:child_process';
for (const key of ['DATABASE_URL', 'CLERK_PUBLISHABLE_KEY', 'CLERK_SECRET_KEY']) {
  if (!process.env[key] || process.env[key].includes('[YOUR-PASSWORD]')) {
    console.error(`Variable ${key} absente ou non renseignée. Ajoutez sa valeur dans Render Environment.`);
    process.exit(1);
  }
}
const child = spawn(process.execPath, ['--enable-source-maps', 'artifacts/api-server/dist/index.mjs'], {
  stdio: 'inherit', env: { ...process.env, NODE_ENV: 'production', SERVE_FRONTEND: 'true' },
});
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => child.kill(signal));
child.on('error', () => { console.error('Impossible de lancer le serveur compilé.'); process.exit(1); });
child.on('exit', (code, signal) => process.exit(code ?? (signal ? 1 : 0)));
