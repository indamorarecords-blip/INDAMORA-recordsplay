# INDAMORA PLAY — préparation Render Free + Supabase

État au 29 octobre 2026 : configuration locale préparée, aucun service Render créé, aucune dépense engagée et aucun changement du domaine ou du projet Replit. Cette préparation doit encore être compilée et testée avec les services réels.

## Ce que contient cette version

- Une seule application Node qui sert l’interface React et les routes API sur la même adresse. Les liens directs vers les pages React sont pris en charge.
- Le contrôle administrateur côté serveur précédemment préparé. Les API privées restent authentifiées ; le serveur distingue l’administrateur vérifié des autres comptes.
- Un fichier render.yaml avec un seul service plan `free`, sans base Render, sans disque et sans déploiements automatiques.
- Des scripts de build et de démarrage. Le build s’arrête si la clé publique Clerk n’est pas renseignée, et le démarrage s’arrête si les variables privées requises manquent.
- Les données restent dans la nouvelle base Supabase. Le stockage local éphémère de Render ne doit pas servir à conserver les médias ou les données.
- Le stockage média dépendant de Replit est explicitement désactivé dans cette configuration ; les tentatives reçoivent un message d’indisponibilité. Il reste à migrer ce service avant d’ouvrir les dépôts d’œuvres.

## Prérequis pour un premier déploiement

1. Ajouter cette version du code dans un dépôt GitHub accessible à Render. Le dépôt existant peut servir, mais les fichiers préparés doivent être effectivement transférés avant tout déploiement. Le fichier local et ce ZIP ne changent pas automatiquement GitHub.
2. Connecter ce dépôt depuis le tableau de bord Render. Conserver `Free` pour le service ; n’ajouter ni base Render, ni disque, ni option payante.
3. Configurer les trois variables ci-dessous dans les champs privés de Render, jamais dans SQL ou dans un fichier commité.
4. Vérifier et valider le Blueprint côté Render, ou renseigner les paramètres du service manuellement.
5. Lancer le build, examiner les logs, et corriger les erreurs avant d’annoncer le site fonctionnel.

## Variables nécessaires

| Nom | Valeur à renseigner en privé |
| --- | --- |
| DATABASE_URL | URI Supabase Session pooler fournie par Supabase, avec le mot de passe de la NOUVELLE base remplacé localement et les caractères réservés correctement encodés. Ajouter `sslmode=verify-full` aux paramètres de l’URI pour TLS avec vérification du certificat. Ne pas désactiver la vérification TLS si une erreur apparaît : examiner la configuration et le certificat. |
| CLERK_PUBLISHABLE_KEY | Clé publique de l’application Clerk existante. Le build l’utilise également pour VITE_CLERK_PUBLISHABLE_KEY. Ce n’est pas une clé Supabase. |
| CLERK_SECRET_KEY | Clé serveur de la même application Clerk. À conserver uniquement côté serveur. |

La connexion Supabase ne rétablit pas les comptes Clerk à elle seule. Les URL de connexion et les domaines autorisés dans Clerk doivent correspondre au nouveau site. Ne pas remplacer une configuration Clerk de production sans en vérifier les conséquences pour le site existant.

Le nom du compte administrateur est actuellement l’adresse principale vérifiée indamorarecords@gmail.com dans Clerk. Le rôle administrateur ne peut pas être choisi dans un formulaire d’inscription.

Le Blueprint configure déjà les valeurs non secrètes : NODE_VERSION=24.22.1, NODE_ENV=production, BASE_PATH=/, SERVE_FRONTEND=true, CLERK_PROXY_ENABLED=false, MEDIA_STORAGE_ENABLED=false, SEED_DEMO_CATALOG=false. Render attribue son PORT au serveur.

## Paramètres si création manuelle d’un Web Service

- Repository : dépôt contenant les fichiers de cette archive, à la racine.
- Branche : main, une fois la copie corrigée transférée.
- Runtime : Node.
- Région proposée : Frankfurt.
- Build command : `node scripts/render-build.mjs`
- Start command : `node scripts/render-start.mjs`
- Health check : `/api/healthz`
- Compute plan : `Free`.
- Automatic deploys : désactivés pendant la reconstruction.
- Ne pas créer de base de données Render : Supabase existe déjà.

## Vérifications réalisées et limites

9 tests ciblés passent sous Node 24 : contrôles administrateur, propriété de la session, absence de cache privé et comportements du serveur de l’interface. Les dépendances Clerk et Express sont simulées dans ces tests unitaires. Ils ne remplacent pas les essais réels du site.

Le YAML est lisible et contrôlé localement : un seul service Free, sans base ni disque. La validation officielle `render blueprints validate render.yaml` n’a pas été exécutée : le CLI Render n’est pas installé et aucun accès CLI authentifié n’est disponible ici.

Les commandes de gestion Render ne sont pas exposées dans cette session, bien que la connexion de l’application soit confirmée. Aucune liste de services ou de workspaces n’a été consultée ; aucune ressource n’a été créée ou modifiée.

Le build complet reste bloqué localement par l’accès refusé au registre npm. Il faudra le lancer sur Render après transfert du code et configuration des variables. L’échec éventuel du build ne doit pas être traité en désactivant les contrôles de sécurité des dépendances.

## Limites de l’offre gratuite vérifiées

Render met un service Free en veille après 15 minutes sans trafic ; son réveil peut prendre environ une minute. Les heures, le trafic et les minutes de build sont limités. Son disque local ne conserve pas les fichiers. Supabase Free peut également se mettre en pause selon l’activité. Le renouvellement du nom de domaine est distinct de l’hébergement gratuit.

Références :
- https://render.com/docs/free
- https://render.com/docs/blueprint-spec
- https://render.com/docs/configure-environment-variables
- https://supabase.com/docs/guides/database/connecting-to-postgres

## Travail restant avant ouverture complète

Raccorder Clerk, vérifier la connexion à la nouvelle base avec les variables privées, migrer les médias, compléter la modération des profils artistes et le suivi presse, compiler et tester les parcours réels. Les anciens contenus, comptes et médias n’ont pas été importés depuis la base Replit suspendue. Ne pas supprimer celle-ci.
