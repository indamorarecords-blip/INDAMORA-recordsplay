import express, { type Express } from "express";
import { existsSync } from "node:fs";
import path from "node:path";

/** Serve the built SPA from the API origin, only when explicitly configured. */
export function mountFrontend(app: Express): void {
  if (process.env.SERVE_FRONTEND !== "true") return;
  const directory = path.resolve(process.cwd(), "artifacts/indamora-play/dist/public");
  const index = path.join(directory, "index.html");
  if (!existsSync(index)) throw new Error("Interface compilée introuvable. Exécutez le build avant le démarrage.");

  // Unknown API routes must never fall back to the HTML application.
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Route API introuvable." });
  });
  app.use(express.static(directory, { index: false, dotfiles: "deny" }));
  app.get("/{*page}", (req, res, next) => {
    if (!req.accepts("html") || path.extname(req.path)) { next(); return; }
    res.set("Cache-Control", "no-store");
    res.sendFile(index);
  });
}
