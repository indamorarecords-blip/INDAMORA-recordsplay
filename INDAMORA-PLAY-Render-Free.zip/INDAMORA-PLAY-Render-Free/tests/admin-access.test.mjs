import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import test from 'node:test';

// Exercise the actual middleware without a live Clerk account, credentials or database.
const state = { userId: null, user: null, error: null };
globalThis.__indamoraAuthTest = state;
const mockUrl = 'data:text/javascript,' + encodeURIComponent(`
export function getAuth() { return { userId: globalThis.__indamoraAuthTest.userId }; }
export const clerkClient = { users: { async getUser() {
  if (globalThis.__indamoraAuthTest.error) throw globalThis.__indamoraAuthTest.error;
  return globalThis.__indamoraAuthTest.user;
} } };
`);
registerHooks({ resolve(specifier, context, nextResolve) {
  if (specifier === '@clerk/express') return { url: mockUrl, shortCircuit: true };
  return nextResolve(specifier, context);
} });
const { requireAuth, requireAdmin, ADMIN_EMAIL } = await import('../artifacts/api-server/src/middlewares/auth.ts');
function response() {
  return { statusCode: 200, body: null, headers: {},
    status(code) { this.statusCode = code; return this; },
    json(value) { this.body = value; return this; },
    set(name, value) { this.headers[name] = value; return this; },
  };
}
function user(email, verified = true) {
  return { primaryEmailAddressId: 'primary', emailAddresses: [{
    id: 'primary', emailAddress: email, verification: { status: verified ? 'verified' : 'unverified' },
  }] };
}
function reset() { state.userId = null; state.user = null; state.error = null; }
async function adminCheck() {
  const req = {}, res = response();
  const nextCalls = [];
  await requireAdmin(req, res, (error) => nextCalls.push(error));
  return { req, res, nextCalls };
}

test('visitor cannot enter the administrator API', async () => {
  reset(); const result = await adminCheck();
  assert.equal(result.res.statusCode, 401); assert.equal(result.nextCalls.length, 0);
});
test('an authenticated artist or ordinary member cannot enter', async () => {
  reset(); state.userId = 'artist'; state.user = user('artist@example.test');
  const result = await adminCheck();
  assert.equal(result.res.statusCode, 403); assert.equal(result.nextCalls.length, 0);
  assert.equal(result.req.clerkIsAdmin, undefined);
});
test('an unverified administrator email cannot enter', async () => {
  reset(); state.userId = 'unverified'; state.user = user(ADMIN_EMAIL, false);
  const result = await adminCheck();
  assert.equal(result.res.statusCode, 403); assert.equal(result.nextCalls.length, 0);
});
test('the verified administrator can enter and sensitive responses are not cached', async () => {
  reset(); state.userId = 'administrator'; state.user = user(ADMIN_EMAIL.toUpperCase());
  const result = await adminCheck();
  assert.deepEqual(result.nextCalls, [undefined]);
  assert.equal(result.req.clerkIsAdmin, true); assert.equal(result.req.clerkUserId, 'administrator');
  assert.equal(result.res.headers['Cache-Control'], 'no-store');
});
test('a secondary administrator address is insufficient', async () => {
  reset(); state.userId = 'member'; state.user = user('member@example.test');
  state.user.emailAddresses.push({ id: 'secondary', emailAddress: ADMIN_EMAIL, verification: { status: 'verified' } });
  const result = await adminCheck();
  assert.equal(result.res.statusCode, 403); assert.equal(result.nextCalls.length, 0);
});
test('Clerk failure fails closed and reaches the error handler', async () => {
  reset(); state.userId = 'unknown'; state.error = new Error('Clerk unavailable');
  const result = await adminCheck();
  assert.deepEqual(result.nextCalls, [state.error]); assert.equal(result.req.clerkIsAdmin, undefined);
});
test('private account endpoints reject visitors and bind signed-in ownership', () => {
  reset(); let called = false; let req = {}, res = response();
  requireAuth(req, res, () => { called = true; });
  assert.equal(res.statusCode, 401); assert.equal(called, false);
  state.userId = 'owner'; req = {}; res = response();
  requireAuth(req, res, () => { called = true; });
  assert.equal(called, true); assert.equal(req.clerkUserId, 'owner');
  assert.equal(res.headers['Cache-Control'], 'no-store');
});
