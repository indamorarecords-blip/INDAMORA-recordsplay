import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
const expressStub = 'data:text/javascript,' + encodeURIComponent(`
export default { static(directory, options) {
  const middleware = () => {};
  middleware.directory = directory;
  middleware.options = options;
  return middleware;
} };
`);
registerHooks({ resolve(specifier, context, nextResolve) {
  if (specifier === 'express') return { url: expressStub, shortCircuit: true };
  return nextResolve(specifier, context);
} });
const { mountFrontend } = await import('../artifacts/api-server/src/lib/serveFrontend.ts');
function app() { return { uses: [], gets: [], use(...args) { this.uses.push(args); }, get(...args) { this.gets.push(args); } }; }
function response() {
  return { code: 200, headers: {}, file: null, body: null,
    status(code) { this.code = code; return this; },
    json(body) { this.body = body; return this; },
    set(key, value) { this.headers[key] = value; return this; },
    sendFile(file) { this.file = file; },
  };
}
test('frontend hosting is opt-in and missing builds fail clearly', () => {
  const before = process.env.SERVE_FRONTEND, cwd = process.cwd();
  const temporary = mkdtempSync(path.join(os.tmpdir(), 'indamora-no-build-'));
  try {
    process.chdir(temporary);
    delete process.env.SERVE_FRONTEND;
    const service = app(); mountFrontend(service);
    assert.equal(service.uses.length, 0);
    process.env.SERVE_FRONTEND = 'true';
    assert.throws(() => mountFrontend(app()), /Interface compilée introuvable/);
  } finally {
    process.chdir(cwd); rmSync(temporary, { recursive: true, force: true });
    if (before === undefined) delete process.env.SERVE_FRONTEND; else process.env.SERVE_FRONTEND = before;
  }
});
test('unknown API returns JSON 404; deep links serve SPA; missing assets do not return HTML', () => {
  const cwd = process.cwd(), before = process.env.SERVE_FRONTEND;
  const temporary = mkdtempSync(path.join(os.tmpdir(), 'indamora-spa-'));
  try {
    const directory = path.join(temporary, 'artifacts/indamora-play/dist/public');
    mkdirSync(directory, { recursive: true }); writeFileSync(path.join(directory, 'index.html'), '<!doctype html>');
    process.chdir(temporary); process.env.SERVE_FRONTEND = 'true';
    const service = app(); mountFrontend(service);
    assert.equal(service.uses[0][0], '/api');
    const api = response(); service.uses[0][1]({}, api);
    assert.equal(api.code, 404); assert.deepEqual(api.body, { error: 'Route API introuvable.' });
    assert.equal(service.uses[1][0].options.dotfiles, 'deny');
    const fallback = service.gets[0][1];
    const page = response(); fallback({ path: '/administration', accepts: () => true }, page, () => assert.fail('deep link not served'));
    assert.equal(page.file, path.join(directory, 'index.html')); assert.equal(page.headers['Cache-Control'], 'no-store');
    for (const request of [{ path: '/assets/missing.js', accepts: () => true }, { path: '/other', accepts: () => false }]) {
      const res = response(); let passed = false; fallback(request, res, () => { passed = true; });
      assert.equal(passed, true); assert.equal(res.file, null);
    }
  } finally {
    process.chdir(cwd); rmSync(temporary, { recursive: true, force: true });
    if (before === undefined) delete process.env.SERVE_FRONTEND; else process.env.SERVE_FRONTEND = before;
  }
});
