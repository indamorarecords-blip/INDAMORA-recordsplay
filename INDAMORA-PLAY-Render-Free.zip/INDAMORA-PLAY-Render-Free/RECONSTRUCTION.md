# INDAMORA PLAY — copie de reconstruction

État au 29 octobre 2026. Cette archive contient le code reçu, avec des corrections ciblées dans une copie indépendante. Elle n’est pas un site déployé et ne contient pas la base de données des utilisateurs.

## Source retrouvée

Source : archive GitHub INDAMORA-recordsplay-main.zip, référence 825eccb502c8a7a3078ceff5576c47a6e17eba81. Les entrées ZIP sont datées du 30 septembre 2026. La copie ne permet pas de comparer avec des versions antérieures : elle ne contient pas l’historique Git.

Le logo et les assets fournis sont conservés, ainsi que les pages : accueil, catalogue, recherche, catégories, répertoire, profils artistes, presse, dépôt d’œuvres, espace artiste, modération, administration, profil, connexion, inscription, Premium et soutien.

## Corrections préparées

- Les liens et pages d’administration s’appuient sur une vérification des droits par le serveur, via GET /api/admin/access. Une comparaison d’adresse email dans le navigateur ne suffit plus pour les afficher.
- Le serveur conserve sa règle existante : seul le compte dont l’adresse principale indamorarecords@gmail.com est vérifiée par Clerk obtient les droits d’administration. Aucun rôle administrateur n’est attribué à partir d’un champ du formulaire ou du stockage local du navigateur.
- Les visiteurs sont redirigés vers la connexion pour les espaces privés, après chargement de la session. Les pages administration et modération attendent la confirmation des droits avant de monter leur contenu.
- L’espace artiste garde la liste et les états de ses propres propositions, sans panneaux de statistiques. Les statistiques de gestion restent dans l’administration.
- Les réponses authentifiées ne doivent pas être mises en cache. Un échec de vérification des droits n’accorde aucun accès administrateur.
- Les erreurs de chargement du tableau de bord sont affichées au lieu de faux compteurs à zéro.
- L’ajout automatique de faux artistes, œuvres et propositions est désactivé par défaut. Il exige désormais NODE_ENV=development et SEED_DEMO_CATALOG=true. Aucune donnée existante n’est supprimée.
- Le frontend utilise les valeurs de développement PORT=5173 et BASE_PATH=/ si elles ne sont pas fournies. La configuration Replit peut toujours les surcharger.

## Constats importants dans la source reçue

1. L’application nécessite PostgreSQL (DATABASE_URL). Le serveur lève une erreur si cette variable manque. Le ZIP ne contient pas de sauvegarde SQL identifiable. Les fichiers sources du schéma ne sont pas les enregistrements des utilisateurs.
2. L’application nécessite la configuration Clerk. Le frontend lève une erreur si la clé publique n’est pas disponible ; cela peut empêcher l’ensemble de l’interface de s’afficher. Le ZIP ne prouve pas l’état du service Clerk utilisé en production.
3. Les médias sont stockés hors du ZIP dans un service de stockage objet. Le code actuel utilise un service local spécifique à Replit sur 127.0.0.1:1106 pour l’authentification du stockage et la signature des URL. Copier ce serveur sur un autre hébergeur ne restaure donc pas les uploads.
4. Les nouveaux profils artistes sont créés « pending » et non publiés. Les lectures publiques ne montrent que les profils approuvés et publiés. Aucun parcours complet d’approbation des profils artistes n’a été trouvé dans les routes serveur de cette copie. La modération d’une œuvre et la publication de son profil sont deux opérations distinctes.
5. Le formulaire presse enregistre des demandes, mais aucune route de consultation/traitement administrateur des demandes presse n’a été trouvée dans cette copie.
6. Les statistiques présentes sont des compteurs de catalogue et de propositions. Aucun système réel de mesure des écoutes, des vues, des revenus ou des paiements n’a été identifié dans ces tables/routes.
7. Les offres Premium et soutien sont présentées comme non payantes dans cette V1. Le code ne restaure pas automatiquement une intégration Stripe antérieure.
8. Le mécanisme de finalisation des uploads réattribue une ACL à partir d’un chemin fourni par le client. Son rattachement à une autorisation d’upload créée pour le même utilisateur doit être vérifié et renforcé avant toute ouverture publique. Ce point n’est pas corrigé dans cette préparation.

Ces constats ne prouvent pas que les fonctions manquantes ont été supprimées par Replit : elles peuvent appartenir à une autre version du projet. Aucun accès à l’hébergement, aux journaux de production, aux comptes ou à la base réelle n’a été utilisé.

## Validation effectuée

Commande : `node --test tests/admin-access.test.mjs` avec Node.js 24.

7 tests du middleware serveur réel sont réussis : refus des visiteurs, refus d’un inscrit/artiste, refus d’une adresse administrateur non vérifiée, admission de l’administrateur vérifié, refus d’une simple adresse secondaire, fermeture de l’accès en cas d’échec Clerk et rattachement de l’identité à la requête authentifiée.

Ces tests simulent le service Clerk et ne contactent aucun compte réel. Ils ne constituent pas des tests de bout en bout des sessions, des routes, du navigateur ou de la base.

L’installation complète des dépendances a été tentée avec le fichier de verrouillage conservé. Elle est bloquée par la restriction réseau de cette session (réponse 403 du registre npm). La compilation TypeScript, le build React et les essais dans un navigateur n’ont donc pas pu être exécutés. Aucun résultat de compilation réussie n’est revendiqué.

## Ce qui reste nécessaire pour remettre le site en service

- Récupérer l’accès à la configuration Clerk existante et vérifier les URL de connexion/inscription du domaine de destination.
- Récupérer une sauvegarde PostgreSQL et les médias d’origine, sans partager publiquement les secrets.
- Comparer avec l’historique ou une autre sauvegarde si des fonctions attendues manquent à cette copie.
- Compléter l’administration des profils artistes et des demandes presse.
- Vérifier et renforcer la propriété des uploads avant une ouverture publique.
- Choisir un hébergement compatible et vérifier ses limites gratuites. Aucun hébergement, abonnement ou engagement payant n’a été souscrit. Le coût du renouvellement d’un domaine reste distinct d’un éventuel hébergement gratuit.
- Exécuter l’installation, le typecheck, le build et les tests de connexion réels une fois les services disponibles.
- Vérifier que tout endpoint privé applique son contrôle côté serveur, puis effectuer la mise en ligne et la liaison du domaine.

Le dépôt GitHub, le site Replit, le domaine et les données d’origine n’ont pas été modifiés.
