// Never include connection values in configuration errors.
export function databaseConfig(env) {
  const raw = env.DATABASE_URL;
  if (!raw?.trim()) throw new Error('DATABASE_URL est absente dans les variables du serveur.');
  let value = raw.trim();
  if (value.includes('[YOUR-PASSWORD]')) {
    if (!env.DATABASE_PASSWORD) throw new Error('DATABASE_PASSWORD est absente : renseignez le mot de passe de la base dans les variables privées du serveur.');
    if (value.split('[YOUR-PASSWORD]').length !== 2) throw new Error('DATABASE_URL contient plusieurs emplacements de mot de passe.');
    value = value.replace('[YOUR-PASSWORD]', encodeURIComponent(env.DATABASE_PASSWORD));
  }
  if (value.startsWith('DATABASE_URL=') || /^["']/.test(value)) {
    throw new Error('DATABASE_URL doit contenir uniquement l’adresse, sans nom de variable ni guillemets.');
  }
  let url;
  try { url = new URL(value); } catch {
    throw new Error('DATABASE_URL est mal formée. Vérifiez l’adresse et l’encodage du mot de passe dans les variables du serveur.');
  }
  if (!['postgres:', 'postgresql:'].includes(url.protocol) || !url.hostname || !url.username || !url.password || url.pathname.length < 2 || url.hash) {
    throw new Error('DATABASE_URL doit être une adresse PostgreSQL complète. Les caractères spéciaux du mot de passe doivent être encodés.');
  }
  return value;
}
