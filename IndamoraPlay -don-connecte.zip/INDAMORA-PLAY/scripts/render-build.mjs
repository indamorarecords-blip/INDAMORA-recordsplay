import { spawnSync } from 'node:child_process';
const env = { ...process.env, NODE_ENV: 'production', BASE_PATH: '/',
  VITE_CLERK_PUBLISHABLE_KEY: process.env.CLERK_PUBLISHABLE_KEY };
if (!env.VITE_CLERK_PUBLISHABLE_KEY?.startsWith('pk_')) {
  console.error('Renseignez CLERK_PUBLISHABLE_KEY dans les variables Render avant le build.');
  process.exit(1);
}
for (const args of [
  ['install', '--frozen-lockfile', '--prod=false'],
  ['run', 'typecheck:libs'],
  ['--filter', '@workspace/api-server', '--filter', '@workspace/indamora-play', 'run', 'typecheck'],
  ['--filter', '@workspace/api-server', 'run', 'build'],
  ['--filter', '@workspace/indamora-play', 'run', 'build'],
]) {
  const result = spawnSync('pnpm', args, { env, stdio: 'inherit' });
  if (result.error || result.status !== 0) {
    console.error('Une étape de préparation a échoué. Consultez les lignes précédentes.');
    process.exit(result.status || 1);
  }
}
const tests = spawnSync(process.execPath, ['--test', 'tests/admin-access.test.mjs', 'tests/serve-frontend.test.mjs',
  'tests/error-diagnostic.test.mjs', 'tests/database-config.test.mjs', 'tests/admin-content.test.mjs',
  'tests/render-start.test.mjs', 'tests/upload-ticket.test.mjs', 'tests/media-path.test.mjs',
  'tests/supabase-storage.test.mjs', 'tests/supabase-media.test.mjs', 'tests/play-stats.test.mjs',
  'tests/origin-policy.test.mjs', 'tests/resumable-upload.test.mjs'], { env, stdio: 'inherit' });
process.exit(tests.status || (tests.error ? 1 : 0));
