# INDAMORA PLAY — projet de reconstruction

Ce projet reprend le code du site fourni par sa propriétaire et les améliorations de l’espace d’administration. Le site est prévu pour un service web gratuit, une base PostgreSQL externe et l’authentification Clerk. Il faut configurer ces services avant de le publier. Les mots de passe et clés secrètes du projet ne sont pas inclus.

## Ce que contient le projet

- La présentation des abonnements non fonctionnels a été retirée ; la page Soutenir permet de diriger vers un lien de don Stripe lorsque celle-ci est configurée. Les œuvres marquées premium restent protégées et indisponibles.
- Les pages du site et son logo, un catalogue et un répertoire alimentés par la base de données.
- L’inscription et la connexion par Clerk, les propositions d’œuvres et l’espace artiste pour le suivi de ses propres propositions.
- L’administration et les fonctions de modération, de validation des profils, de demandes presse et de liste des inscrits, réservées à l’administrateur identifié par son adresse principale vérifiée.
- Les démarrages du lecteur peuvent être comptabilisés et consultés dans l’administration. Ce sont des démarrages, pas des auditeurs uniques ni des données de revenus ; ils peuvent être affectés par les répétitions et les interruptions.
- Le fichier `deployment/INDAMORAPLAY-initialisation.sql` initialise une **nouvelle base vide**. Il ne récupère pas les données de Replit. Ne pas l’exécuter sur une base existante sans vérification et sauvegarde.

## Configuration privée

Ne jamais placer les mots de passe ou clés secrètes dans GitHub. Les mettre dans les variables privées du service d’hébergement.

- `DATABASE_URL` : URL PostgreSQL complète avec le mot de passe encodé, **ou** URL du pooler Supabase avec le texte `[YOUR-PASSWORD]` conservé.
- Si le texte `[YOUR-PASSWORD]` est conservé dans `DATABASE_URL`, ajouter une variable séparée `DATABASE_PASSWORD` contenant le mot de passe de la base en clair. Le serveur l’encode lui-même. Cette variable est privée et ne doit pas être partagée.
- `CLERK_PUBLISHABLE_KEY` et `CLERK_SECRET_KEY` : clés de la même application Clerk.
- `CLERK_PROXY_ENABLED=false` et `MEDIA_STORAGE_ENABLED=false` par défaut.
- Une intégration Supabase Storage a été préparée pour les fichiers de 50 Mo maximum. Avant de l’activer, créer un compartiment **privé** avec une limite maximale de 50 Mo et configurer `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_MEDIA_BUCKET` et `UPLOAD_SIGNING_SECRET` dans les variables privées, ainsi que `MEDIA_STORAGE_PROVIDER=supabase` et `MEDIA_STORAGE_ENABLED=true`. Le serveur refuse un compartiment public ou sans limite de taille configurée.
- La clé `UPLOAD_SIGNING_SECRET` doit être aléatoire, d’au moins 32 octets, unique et conservée d’un redéploiement à l’autre. La changer sans migration peut empêcher les propriétaires d’accéder à leurs fichiers. Ne jamais partager cette clé ou la clé serveur Supabase.
- Cette intégration reste à tester sur de vrais comptes et un vrai compartiment. Les fichiers de plus de 6 Mo utilisent un envoi par morceaux avec reprise pendant la même session ; la reprise après fermeture de l’application n’est pas encore implémentée. La limite de 50 Mo par fichier découle de l’offre gratuite Supabase actuelle.

## Dons pour l’association

Le lien public de don Stripe communiqué par la propriétaire est intégré dans le site. Pour le remplacer, configurer `VITE_STRIPE_DONATION_URL` au moment de la compilation avec une URL Stripe de don en mode réel (`donate.stripe.com` ou `buy.stripe.com`). Vérifier que le lien appartient au compte de l’association et effectuer un test de bout en bout. Les liens de test ne sont pas acceptés pour la collecte publique. En cas d’URL configurée invalide, aucun paiement n’est proposé. Cette variable est publique : elle ne doit jamais contenir de secret. Stripe peut facturer des frais par transaction ; aucun abonnement payant n’est nécessaire pour le lien standard.

## État des vérifications

Les tests fournis vérifient en particulier les contrôles d’accès à l’administration, les statuts, le diagnostic sans divulgation du secret, le démarrage et les restrictions sur les médias. Certains remplacent les services extérieurs par des simulations : ils ne prouvent pas que les vrais comptes, la vraie base ou le vrai stockage sont configurés.

La version précédente de ce code a été compilée avec succès sur Render le 31 octobre 2026 ; les modifications les plus récentes ont été vérifiées localement par tests, mais n’ont pas encore été compilées sur l’hébergement ni testées avec une vraie base.

## Ce qui reste à terminer

1. Mettre les variables privées avec les vraies valeurs et vérifier la connexion à la base.
2. Tester les parcours complets avec les comptes réels, dont l’accès refusé à l’administration pour les visiteurs et les artistes.
3. Configurer le stockage Supabase privé, compiler, puis tester l’envoi, la validation et la lecture avec de vrais comptes et de vrais fichiers. Les fichiers de plus de 50 Mo ne sont pas pris en charge dans cette version.
4. Sur une base existante ayant déjà les quatre tables initiales, exécuter la migration additive `deployment/INDAMORAPLAY-statistiques.sql` après vérification. Le script complet d’initialisation inclut la table de statistiques pour une nouvelle base.
5. Récupérer les anciennes données si elles sont disponibles : elles ne sont pas incluses dans le code source.
6. Après validation du service, relier le domaine indamoraplay.com auprès de son fournisseur.

Les paiements réels, les auditeurs uniques et les statistiques de revenus ne sont pas implémentés. Cette archive ne peut donc pas être présentée comme une reproduction entièrement opérationnelle du site d’origine. Les offres gratuites ont des limites ; l’hébergement, les comptes et le domaine doivent être vérifiés avant toute mise en ligne.
