-- Migration additive : aucun contenu existant n’est supprimé.
BEGIN;
CREATE TABLE IF NOT EXISTS public.work_play_counts (
  work_id integer PRIMARY KEY REFERENCES public.works(id) ON DELETE CASCADE,
  plays bigint NOT NULL DEFAULT 0 CHECK (plays >= 0)
);
ALTER TABLE public.work_play_counts ENABLE ROW LEVEL SECURITY;
REVOKE ALL PRIVILEGES ON TABLE public.work_play_counts FROM PUBLIC, anon, authenticated;
COMMIT;
