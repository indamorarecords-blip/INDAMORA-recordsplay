-- INDAMORA PLAY : initialisation d'une NOUVELLE base vide.
-- Compatible avec les quatre tables du serveur Express/Clerk existant.
-- Aucun ancien compte ni media n'est importe par ce script.
-- Acces aux donnees via le serveur uniquement ; aucune API navigateur autorisee.
-- Si une table existe deja, la transaction est annulee sans la remplacer.
BEGIN;

CREATE TABLE public.artists (
  id serial PRIMARY KEY,
  name text NOT NULL,
  category text NOT NULL,
  bio text NOT NULL,
  location text NOT NULL,
  avatar text,
  works_count integer NOT NULL DEFAULT 0,
  owner_id text,
  profile_group text NOT NULL DEFAULT 'artists',
  subcategory text,
  country text,
  specialties text[] NOT NULL DEFAULT '{}',
  website text,
  social_links text[] NOT NULL DEFAULT '{}',
  professional_contact text,
  profile_status text NOT NULL DEFAULT 'approved',
  is_published text NOT NULL DEFAULT 'true',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.works (
  id serial PRIMARY KEY,
  title text NOT NULL,
  artist text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  duration text,
  image text NOT NULL,
  media_type text,
  media_object_path text,
  cover_object_path text,
  featured text NOT NULL DEFAULT 'false',
  access text NOT NULL DEFAULT 'free',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.submissions (
  id serial PRIMARY KEY,
  title text NOT NULL,
  artist text NOT NULL,
  category text NOT NULL,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'pending',
  note text,
  owner_id text,
  media_type text,
  media_object_path text,
  cover_object_path text,
  duration text,
  published_work_id integer
);

CREATE TABLE public.press_requests (
  id serial PRIMARY KEY,
  name text NOT NULL,
  organization text NOT NULL,
  role text NOT NULL,
  email text NOT NULL,
  phone text,
  request_type text NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  requested_date text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.artists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.works ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.press_requests ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.work_play_counts (
  work_id integer PRIMARY KEY REFERENCES public.works(id) ON DELETE CASCADE,
  plays bigint NOT NULL DEFAULT 0 CHECK (plays >= 0)
);
ALTER TABLE public.work_play_counts ENABLE ROW LEVEL SECURITY;

REVOKE ALL PRIVILEGES ON TABLE
  public.artists, public.works,
  public.submissions, public.press_requests, public.work_play_counts
FROM PUBLIC, anon, authenticated;

REVOKE ALL PRIVILEGES ON SEQUENCE
  public.artists_id_seq, public.works_id_seq,
  public.submissions_id_seq, public.press_requests_id_seq
FROM PUBLIC, anon, authenticated;

COMMIT;

-- Verification : cinq lignes avec rls_active = true et les droits a false.
SELECT c.relname AS table_name,
  c.relrowsecurity AS rls_active,
  has_table_privilege('anon', c.oid, 'SELECT') AS visiteur_lecture,
  has_table_privilege('authenticated', c.oid, 'SELECT') AS inscrit_lecture,
  has_table_privilege('authenticated', c.oid, 'INSERT') AS inscrit_ajout,
  has_table_privilege('authenticated', c.oid, 'UPDATE') AS inscrit_modification
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('artists', 'works', 'submissions', 'press_requests', 'work_play_counts')
ORDER BY c.relname;
