# INDAMORA PLAY — reconstruction du 31 octobre 2026

Ce document décrit une version antérieure. Pour l’état actuel et les nouvelles fonctions, lire d’abord `LISEZ-MOI-EN-PREMIER.md`.

Cette archive reprend le code original fourni, son logo, ses pages et la navigation mobile. Elle ne contient aucun identifiant de connexion.

## Changements de cette version

- Administration protégée côté serveur par la vérification de l’adresse principale vérifiée du compte Clerk administrateur.
- Ajout de la validation des profils : valider et publier, refuser ou remettre en attente. La création d’un profil reste en attente jusqu’à validation.
- Ajout de la consultation des demandes presse et de leur suivi : en attente, traitée ou archivée.
- Pagination des deux nouvelles listes pour limiter le volume de données chargé.
- Diagnostic serveur limité à des codes autorisés : les valeurs de connexion et les messages SQL bruts ne sont pas renvoyés au navigateur.
- Vérification de DATABASE_URL au démarrage. Une valeur invalide produit un message explicite sans reproduire le secret.
- Démarrage indépendant du répertoire courant : la commande n’a plus besoin de commencer par `cd`.
- Message d’échec du chargement corrigé : il n’attribue plus systématiquement le problème à la connexion Internet du visiteur.

## Validation

19 tests automatisés passent : accès, autorisations des nouvelles routes, validation des entrées, publication et retrait, pagination, configuration de connexion, confidentialité des diagnostics et démarrage depuis un autre dossier.

Les routes sont vérifiées avec des dépendances simulées et le véritable middleware d’autorisation. Ces tests ne remplacent pas une vérification avec de vrais comptes et une vraie base.

Le 29 octobre, les logs Render de la version précédente confirmaient la compilation et 9 tests réussis. Cette nouvelle version n’a pas été entièrement compilée ici : l’installation des dépendances est refusée par le registre réseau (403). Aucun contrôle n’a été désactivé pour contourner ce refus.

## Ce qui reste à effectuer avant la remise en service

1. Corriger la valeur DATABASE_URL dans les variables privées de Render. Les derniers logs fournis montrent ERR_INVALID_URL. Cette archive ne peut pas deviner ni réparer un secret privé absent de la session.
2. Compiler et déployer cette version depuis le dépôt GitHub.
3. Vérifier les parcours réels avec un administrateur, un artiste et un visiteur.
4. Restaurer, si elles sont récupérables, les anciennes œuvres et les données depuis Replit. Le schéma Supabase a été comparé au code : les 56 colonnes correspondent, mais cela ne signifie pas que les anciennes données ont été migrées.
5. Rebrancher un stockage durable des fichiers. Les médias restent désactivés avec MEDIA_STORAGE_ENABLED=false ; le stockage temporaire du serveur ne convient pas aux œuvres.
6. Après validation de Render, rattacher le domaine indamoraplay.com. La capture du 31 octobre affiche une page Replit indiquant qu’aucune application publiée n’est accessible à cette adresse.

Les statistiques d’écoute ou de revenus et les paiements réels ne sont pas implémentés par cette version. Les compteurs administrateur existants concernent le catalogue et la modération.

## Déploiement sans modifier l’arborescence sur iPhone

Si cette archive est déposée telle quelle à la racine du dépôt, utiliser :

Build Command :

```bash
unzip -o INDAMORA-PLAY-Reconstruction-31-10-2026.zip -d render-build && cd render-build/INDAMORA-PLAY-Render-Free && node scripts/render-build.mjs
```

Start Command :

```bash
node render-build/INDAMORA-PLAY-Render-Free/scripts/render-start.mjs
```

Garder Root Directory vide. Ces commandes remplacent celles de l’ancienne archive uniquement après le dépôt de la nouvelle archive. Si les sources sont extraites à la racine du dépôt, utiliser plutôt `node scripts/render-build.mjs` et `node scripts/render-start.mjs`.

Conserver les secrets uniquement dans les variables privées du serveur. Ne pas transmettre DATABASE_URL ni le mot de passe dans une capture ou un message. Aucune modification du domaine n’est nécessaire avant que le service de remplacement fonctionne.

L’offre payante n’est pas autorisée. Cette livraison n’a créé aucun service et n’a modifié aucun abonnement. La disponibilité continue dépend des limites des offres gratuites ; aucun service illimité n’est promis.
