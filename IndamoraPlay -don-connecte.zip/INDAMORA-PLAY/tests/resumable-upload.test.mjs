import test from 'node:test';
import assert from 'node:assert/strict';
import { resumableUpload } from '../artifacts/indamora-play/src/lib/resumable-upload.ts';

const chunk=6*1024*1024;
const details={endpoint:'https://project.storage.supabase.co/storage/v1/upload/resumable',token:'signed-token',bucket:'indamora-media',objectName:'uploads/test'};
test('sends a large file in six-megabyte chunks using only the scoped upload signature',async()=>{
  const calls=[];let offset=0;const previous=globalThis.fetch;
  globalThis.fetch=async(url,options)=>{
    calls.push({url,options});
    if(options.method==='POST')return new Response(null,{status:201,headers:{Location:'/storage/v1/upload/resumable/session'}});
    assert.equal(options.method,'PATCH');assert.equal(options.headers['Upload-Offset'],String(offset));
    offset+=options.body.size;
    return new Response(null,{status:204,headers:{'Upload-Offset':String(offset)}});
  };
  try {
    const file=new Blob([new Uint8Array(chunk+42)],{type:'audio/mpeg'});const progress=[];
    await resumableUpload(file,details,value=>progress.push(value));
    assert.equal(calls.length,3);assert.equal(calls[1].options.body.size,chunk);assert.equal(calls[2].options.body.size,42);
    assert.equal(calls[1].options.headers['x-signature'],'signed-token');assert.equal(progress.at(-1),100);
  } finally {globalThis.fetch=previous}
});
test('never sends the signature to a redirected or untrusted destination',async()=>{
  const previous=globalThis.fetch;
  try {
    globalThis.fetch=async()=>new Response(null,{status:201,headers:{Location:'https://evil.example/storage/v1/upload/resumable/session'}});
    await assert.rejects(()=>resumableUpload(new Blob(['a'],{type:'audio/mpeg'}),details,()=>{}),/Adresse de reprise invalide/);
    await assert.rejects(()=>resumableUpload(new Blob(['a'],{type:'audio/mpeg'}),{...details,endpoint:'https://evil.example/storage/v1/upload/resumable'},()=>{}),/Adresse de stockage invalide/);
  } finally {globalThis.fetch=previous}
});
test('recovers the acknowledged offset after an interrupted transfer',async()=>{
  const previous=globalThis.fetch;let patches=0;
  globalThis.fetch=async(_url,options)=>{
    if(options.method==='POST')return new Response(null,{status:201,headers:{Location:'/storage/v1/upload/resumable/session'}});
    if(options.method==='HEAD')return new Response(null,{status:200,headers:{'Upload-Offset':'0'}});
    if(++patches===1)throw new Error('connection lost');
    return new Response(null,{status:204,headers:{'Upload-Offset':'3'}});
  };
  try {await resumableUpload(new Blob(['abc'],{type:'audio/mpeg'}),details,()=>{});assert.equal(patches,2)}
  finally {globalThis.fetch=previous}
});
