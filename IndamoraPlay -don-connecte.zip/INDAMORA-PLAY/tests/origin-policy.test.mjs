import test from 'node:test';
import assert from 'node:assert/strict';
import { allowedOrigin } from '../artifacts/api-server/src/lib/origin-policy.ts';

test('only the website’s own HTTPS origin can make credentialed cross-origin requests', () => {
  assert.equal(allowedOrigin('https://indamoraplay.com','indamoraplay.com',true),true);
  assert.equal(allowedOrigin('https://evil.example','indamoraplay.com',true),false);
  assert.equal(allowedOrigin('http://indamoraplay.com','indamoraplay.com',true),false);
  assert.equal(allowedOrigin('https://indamoraplay.com.evil.example','indamoraplay.com',true),false);
  assert.equal(allowedOrigin('null','indamoraplay.com',true),false);
  assert.equal(allowedOrigin(undefined,'indamoraplay.com',true),false);
  assert.equal(allowedOrigin('http://localhost:5173','localhost:5173',false),true);
});
