import assert from 'node:assert/strict';
import test from 'node:test';
import { databaseConfig } from '../scripts/database-config.mjs';

test('accepts a complete encoded PostgreSQL URL and trims surrounding whitespace', () => {
  const value = 'postgresql://postgres.project:p%40ss@host.test:5432/postgres?sslmode=verify-full';
  assert.equal(databaseConfig({DATABASE_URL:' \n'+value+'\n'}), value);
});
test('reports invalid configuration without disclosing any supplied value', () => {
  for (const value of [undefined, '', 'DATABASE_URL=postgres://u:SECRET@h/db', '"postgres://u:SECRET@h/db"', 'https://u:SECRET@h/db', 'postgresql://u:SECRET@h/db#fragment', 'postgresql://u:SECRET@h:bad/db']) {
    assert.throws(() => databaseConfig({DATABASE_URL:value}), error => {
      assert.ok(!error.message.includes('SECRET'));
      return /DATABASE_URL/.test(error.message);
    });
  }
});
test('accepts the Supabase placeholder with a separately stored password and encodes reserved characters', () => {
  const template='postgresql://postgres.project:[YOUR-PASSWORD]@host.test:5432/postgres?sslmode=verify-full';
  assert.throws(() => databaseConfig({DATABASE_URL:template}), /DATABASE_PASSWORD/);
  const url=databaseConfig({DATABASE_URL:template,DATABASE_PASSWORD:'a@b/#% x'});
  assert.equal(url,'postgresql://postgres.project:a%40b%2F%23%25%20x@host.test:5432/postgres?sslmode=verify-full');
  assert.equal(decodeURIComponent(new URL(url).password),'a@b/#% x');
});
