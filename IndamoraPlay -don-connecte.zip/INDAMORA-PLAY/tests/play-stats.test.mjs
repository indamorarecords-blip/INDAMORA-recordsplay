import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import test from 'node:test';
const state={routes:[],role:null,queries:[]}; globalThis.__playStatsTest=state;
const data=code=>'data:text/javascript,'+encodeURIComponent(code);
const mocks={
 express:data(`export function Router(){const r=globalThis.__playStatsTest.routes;return {post(path,...handlers){r.push({method:'POST',path,handlers})},get(path,...handlers){r.push({method:'GET',path,handlers})}}}`),
 '@workspace/db':data(`export const pool={async query(sql,params){globalThis.__playStatsTest.queries.push({sql,params});return {rows:[{title:'Œuvre',artist:'Artiste',plays:'9'}]}}}`),
 '@clerk/express':data(`export function getAuth(){return {userId:globalThis.__playStatsTest.role}}; export const clerkClient={users:{async getUser(){return {primaryEmailAddressId:'p',emailAddresses:[{id:'p',emailAddress:globalThis.__playStatsTest.role==='admin'?'indamorarecords@gmail.com':'artist@example.test',verification:{status:'verified'}}]}}}};`),
};
registerHooks({resolve(specifier,context,next){
 if(mocks[specifier])return {url:mocks[specifier],shortCircuit:true};
 if(specifier==='../middlewares/auth')return {url:new URL('../artifacts/api-server/src/middlewares/auth.ts',import.meta.url).href,shortCircuit:true};
 return next(specifier,context);
}});
await import('../artifacts/api-server/src/routes/play-stats.ts');
async function invoke(method,path,id='4'){
 const route=state.routes.find(r=>r.method===method&&r.path===path);
 const req={params:{id}};const res={code:200,body:undefined,headers:{},set(k,v){this.headers[k]=v;return this},status(c){this.code=c;return this},sendStatus(c){this.code=c;return this},json(v){this.body=v;return this}};
 for(const h of route.handlers){let next=false;await h(req,res,e=>{assert.equal(e,undefined);next=true});if(!next)break}return res;
}
test('playback events are write-only and reject invalid identifiers',async()=>{
 state.role=null;state.queries=[];
 assert.equal((await invoke('POST','/works/:id/play','-1')).code,400);assert.equal(state.queries.length,0);
 const res=await invoke('POST','/works/:id/play','42');
 assert.equal(res.code,204);assert.equal(res.body,undefined);assert.deepEqual(state.queries[0].params,[42]);
 assert.match(state.queries[0].sql,/access = 'free'/);
});
test('only the verified administrator receives play statistics',async()=>{
 state.queries=[];for(const role of [null,'artist']){state.role=role;const res=await invoke('GET','/admin/play-stats');assert.equal(res.code,role?403:401)}
 assert.equal(state.queries.length,0);state.role='admin';const result=await invoke('GET','/admin/play-stats');
 assert.equal(result.code,200);assert.equal(result.headers['Cache-Control'],'no-store');assert.equal(result.body.works[0].plays,'9');
});
