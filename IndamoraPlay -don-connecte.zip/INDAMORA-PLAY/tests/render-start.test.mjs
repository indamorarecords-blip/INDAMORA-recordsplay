import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, copyFileSync, writeFileSync, rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';

test('startup works from another directory and passes production settings to server', () => {
  const root = mkdtempSync(path.join(tmpdir(), 'indamora-start-'));
  try {
    mkdirSync(path.join(root, 'scripts'));
    mkdirSync(path.join(root, 'artifacts/api-server/dist'), {recursive:true});
    for (const file of ['render-start.mjs','database-config.mjs']) {
      copyFileSync(new URL('../scripts/'+file, import.meta.url), path.join(root,'scripts',file));
    }
    writeFileSync(path.join(root,'artifacts/api-server/dist/index.mjs'), `console.log(JSON.stringify({cwd:process.cwd(),production:process.env.NODE_ENV,frontend:process.env.SERVE_FRONTEND}));`);
    const result = spawnSync(process.execPath,[path.join(root,'scripts/render-start.mjs')],{
      cwd:tmpdir(),encoding:'utf8',env:{...process.env,DATABASE_URL:'postgresql://u:p@host.test/db',CLERK_PUBLISHABLE_KEY:'pk_test_example',CLERK_SECRET_KEY:'sk_test_example'},
    });
    assert.equal(result.status,0,result.stderr);
    assert.deepEqual(JSON.parse(result.stdout),{cwd:root,production:'production',frontend:'true'});
  } finally { rmSync(root,{recursive:true,force:true}); }
});
test('invalid database URL exits cleanly without echoing it or a secret-bearing stack', () => {
  const result=spawnSync(process.execPath,[new URL('../scripts/render-start.mjs',import.meta.url).pathname],{
    encoding:'utf8',env:{...process.env,DATABASE_URL:'postgresql://u:SECRET@host.test:BAD/db'},
  });
  assert.equal(result.status,1);
  assert.match(result.stderr,/DATABASE_URL est mal formée/);
  assert.ok(!result.stderr.includes('SECRET'));
  assert.ok(!result.stderr.includes('input:'));
});
