import assert from 'node:assert/strict';
import test from 'node:test';
import { errorDiagnostic } from '../artifacts/api-server/src/lib/errorDiagnostic.ts';

test('finds nested database errors without disclosing credentials or query data', () => {
  const secret = 'postgresql://user:SECRET@example.invalid/db';
  const cause = Object.assign(new Error(secret), {code:'28P01', detail:secret});
  const result = errorDiagnostic(new Error('Failed query: PRIVATE DATA', {cause}));
  assert.deepEqual(result, {code:'28P01', category:'database_authentication'});
  assert.ok(!JSON.stringify(result).includes('SECRET'));
});
test('distinguishes schema and certificate errors; terminates cyclic causes', () => {
  assert.equal(errorDiagnostic({cause:{code:'42703'}}).category, 'database_missing_column');
  assert.equal(errorDiagnostic({code:'SELF_SIGNED_CERT_IN_CHAIN'}).category, 'database_tls');
  const cyclic = {code:'SECRET'}; cyclic.cause = cyclic;
  assert.deepEqual(errorDiagnostic(cyclic), {code:'UNKNOWN',category:'server_error'});
  assert.equal(errorDiagnostic(null).code, 'UNKNOWN');
});
