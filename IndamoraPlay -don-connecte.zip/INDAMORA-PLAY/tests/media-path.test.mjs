import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { uploadObjectPath, storageObjectName, isObjectOwner } from '../artifacts/api-server/src/lib/media-path.ts';

test('private paths bind uploads to the original authenticated user without exposing their id', () => {
  const secret='a'.repeat(32), id=randomUUID();
  const path=uploadObjectPath('user_private',id,secret);
  assert.equal(path.includes('user_private'),false);
  assert.equal(isObjectOwner(path,'user_private',secret),true);
  assert.equal(isObjectOwner(path,'different_user',secret),false);
  assert.equal(isObjectOwner(path,'user_private','b'.repeat(32)),false);
  assert.equal(storageObjectName(path),path.slice('/objects/'.length));
});
test('rejects forged paths and traversal', () => {
  const secret='a'.repeat(32), valid=uploadObjectPath('user',randomUUID(),secret);
  for (const path of [valid+'/../other',valid.replace('/objects/','/objects/../'),'/objects/uploads/x/file','https://evil.test/'+valid]) {
    assert.equal(storageObjectName(path),null);
    assert.equal(isObjectOwner(path,'user',secret),false);
  }
});
