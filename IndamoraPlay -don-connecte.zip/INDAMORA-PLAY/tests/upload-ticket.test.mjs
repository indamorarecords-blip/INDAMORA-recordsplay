import assert from 'node:assert/strict';
import test from 'node:test';
import { createUploadTicket, verifyUploadTicket } from '../artifacts/api-server/src/lib/upload-ticket.ts';

const secret = '0123456789abcdef0123456789abcdef';
test('a signed upload is bound to its creator, content type, size and expiry', () => {
  const {token,id} = createUploadTicket({ownerId:'user_1',mime:'audio/mpeg',size:1234},secret,1000);
  const claims = verifyUploadTicket(token,'user_1',secret,1001);
  assert.equal(claims.id,id); assert.equal(claims.mime,'audio/mpeg'); assert.equal(claims.size,1234);
  assert.equal(verifyUploadTicket(token,'user_2',secret,1001),null);
  assert.equal(verifyUploadTicket(token,'user_1',secret,7201000),null);
  assert.equal(verifyUploadTicket(token,'user_1','x'.repeat(32),1001),null);
});
test('rejects tampering, malformed tokens, unsafe types and oversized uploads', () => {
  const {token} = createUploadTicket({ownerId:'owner',mime:'image/png',size:5},secret,1000);
  assert.equal(verifyUploadTicket(token+'X','owner',secret,1001),null);
  assert.equal(verifyUploadTicket('invalid.token.more','owner',secret,1001),null);
  assert.throws(()=>createUploadTicket({ownerId:'owner',mime:'text/html',size:5},secret));
  assert.throws(()=>createUploadTicket({ownerId:'owner',mime:'audio/mpeg',size:50*1024*1024+1},secret));
  assert.throws(()=>createUploadTicket({ownerId:'owner',mime:'audio/mpeg',size:1},'short'));
});
