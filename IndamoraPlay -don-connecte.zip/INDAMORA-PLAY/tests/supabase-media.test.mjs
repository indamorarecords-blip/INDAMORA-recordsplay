import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { registerHooks } from 'node:module';
import { uploadObjectPath } from '../artifacts/api-server/src/lib/media-path.ts';

const state={queries:[],calls:[]}; globalThis.__mediaProviderTest=state;
const db='data:text/javascript,'+encodeURIComponent(`export const pool={async query(sql,params){globalThis.__mediaProviderTest.queries.push({sql,params});return {rows:[{mime:'audio/mpeg',size:'3'}]}}};`);
registerHooks({resolve(specifier,context,next){
  if(specifier==='@workspace/db')return {url:db,shortCircuit:true};
  if(specifier==='./media-path')return {url:new URL('../artifacts/api-server/src/lib/media-path.ts',import.meta.url).href,shortCircuit:true};
  return next(specifier,context);
}});
const {mediaConfig,objectMetadata,putObject,downloadObject,createLargeUpload}=await import('../artifacts/api-server/src/lib/supabase-media.ts');
Object.assign(process.env,{SUPABASE_URL:'https://project.supabase.co',SUPABASE_MEDIA_BUCKET:'indamora-media',SUPABASE_SERVICE_ROLE_KEY:'test-private-service-key',UPLOAD_SIGNING_SECRET:'x'.repeat(32)});
globalThis.fetch=async(url,options)=>{state.calls.push({url,options});return url.includes('/bucket/') ? Response.json({id:'indamora-media',public:false,file_size_limit:50*1024*1024}) : new Response(null,{status:200})};
test('storage operations use private server credentials, bounded object paths and read-only metadata queries',async()=>{
  const path=uploadObjectPath('owner',randomUUID(),'x'.repeat(32));
  assert.deepEqual(await objectMetadata(path),{mime:'audio/mpeg',size:3});
  assert.deepEqual(state.queries.at(-1).params,['indamora-media',path.slice('/objects/'.length)]);
  assert.match(state.queries.at(-1).sql,/^SELECT /);
  await putObject(path,Buffer.from('abc'),'audio/mpeg');
  assert.equal(state.calls.at(-1).options.method,'POST');
  assert.equal(state.calls.at(-1).options.headers['x-upsert'],'false');
  assert.equal(state.calls.at(-1).options.headers.Authorization,'Bearer test-private-service-key');
  await downloadObject(path,'bytes=0-2');
  assert.equal(state.calls.at(-1).options.headers.Range,'bytes=0-2');
  assert.match(state.calls.at(-1).url,/\/object\/authenticated\/indamora-media\//);
  assert.equal(await objectMetadata('/objects/../../elsewhere'),null);
  await assert.rejects(()=>putObject('/objects/../../bad',Buffer.from('x'),'audio/mpeg'));
});
test('invalid media configuration is rejected without revealing secrets',()=>{
  process.env.SUPABASE_URL='https://user:password@evil.test/';
  assert.throws(()=>mediaConfig(),e=>!e.message.includes('password'));
  process.env.SUPABASE_URL='https://project.supabase.co';
});
test('upload refuses a public bucket before writing any file',async()=>{
  const before=state.calls.length;
  globalThis.fetch=async(url,options)=>{state.calls.push({url,options});return Response.json({id:'indamora-media',public:true})};
  const path=uploadObjectPath('owner',randomUUID(),'x'.repeat(32));
  await assert.rejects(()=>putObject(path,Buffer.from('abc'),'audio/mpeg'),/private/);
  assert.equal(state.calls.length,before+1);
});
test('large upload gets a scoped signature without exposing the service key to the client',async()=>{
  globalThis.fetch=async(url,options)=>{
    state.calls.push({url,options});
    return url.includes('/bucket/') ? Response.json({id:'indamora-media',public:false,file_size_limit:50*1024*1024}) : Response.json({url:'/object/upload/sign/indamora-media/file?token=scoped-upload-token'});
  };
  const path=uploadObjectPath('owner',randomUUID(),'x'.repeat(32));
  const response=await createLargeUpload(path,12*1024*1024);
  assert.equal(response.token,'scoped-upload-token');
  assert.equal(response.endpoint,'https://project.storage.supabase.co/storage/v1/upload/resumable');
  assert.equal(response.objectName,path.slice('/objects/'.length));
  assert.equal(JSON.stringify(response).includes('test-private-service-key'),false);
});
