import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { randomUUID } from 'node:crypto';
import test from 'node:test';
import { uploadObjectPath } from '../artifacts/api-server/src/lib/media-path.ts';

const key = 'x'.repeat(32);
const state = { routes: [], role: null, uploaded: [], published: false, downloads: 0 };
globalThis.__storageTest = state;
const data = code => 'data:text/javascript,' + encodeURIComponent(code);
const mocks = {
  express: data(`export function Router(){const r=globalThis.__storageTest.routes;return {post(path,...handlers){r.push({method:'POST',path,handlers})},put(path,...handlers){r.push({method:'PUT',path,handlers})},get(path,...handlers){r.push({method:'GET',path,handlers})}}} export default {raw(){return (_req,_res,next)=>next()}};`),
  '@clerk/express': data(`export function getAuth(){return {userId:globalThis.__storageTest.role}};export const clerkClient={users:{async getUser(){return {primaryEmailAddressId:'p',emailAddresses:[{id:'p',emailAddress:globalThis.__storageTest.role==='admin'?'indamorarecords@gmail.com':'artist@example.test',verification:{status:'verified'}}]}}}};`),
  'drizzle-orm': data(`export function eq(a,b){return {a,b}};export function and(...args){return args};export function or(...args){return args};`),
  '@workspace/db': data(`export const worksTable={id:'id',access:'access',mediaObjectPath:'media',coverObjectPath:'cover'};export const db={select(){return {from(){return {where(){return {async limit(){return globalThis.__storageTest.published?[{id:1}]:[]}}}}}}}};`),
  '@workspace/api-zod': data(`export const RequestUploadUrlBody={safeParse(data){return {success:true,data}}};export const CompleteUploadBody={safeParse(data){return {success:typeof data?.objectPath==='string',data}}};`),
};
const storage = data(`
 export function mediaConfig(){return {secret:'${key}'}};
 export async function putObject(path,body,mime){globalThis.__storageTest.uploaded.push({path,size:body.length,mime})};
 export async function createLargeUpload(){return {endpoint:'https://example.supabase.co/storage/v1/upload/resumable',token:'signed',bucket:'indamora-media',objectName:'uploads/example'}};
 export async function objectMetadata(){return {mime:'audio/mpeg',size:3}};
 export async function downloadObject(){globalThis.__storageTest.downloads++;return new Response(null,{status:200,headers:{'content-type':'audio/mpeg'}})};
`);
registerHooks({resolve(specifier,context,next) {
  if (mocks[specifier]) return {url:mocks[specifier],shortCircuit:true};
  if (specifier === '../lib/supabase-media') return {url:storage,shortCircuit:true};
  if (specifier.startsWith('../lib/') || specifier === '../middlewares/auth') {
    return {url:new URL('../artifacts/api-server/src/'+specifier.slice(3)+'.ts',import.meta.url).href,shortCircuit:true};
  }
  return next(specifier,context);
}});
await import('../artifacts/api-server/src/routes/supabase-storage.ts');

async function invoke(method,path,{body,params={},headers={}}={}) {
  const route=state.routes.find(r=>r.method===method && r.path===path);
  const req={body,params,headers,get(name){return headers[name.toLowerCase()]}};
  const res={code:200,body:null,headers:{},ended:false,set(k,v){this.headers[k.toLowerCase()]=v;return this;},status(c){this.code=c;return this;},json(v){this.body=v;return this;},end(){this.ended=true;return this;}};
  for (const handler of route.handlers) {
    let advanced=false; await handler(req,res,error=>{assert.equal(error,undefined);advanced=true});
    if (!advanced) break;
  }
  return res;
}
test('an authenticated owner can upload, but another user cannot replay the ticket',async()=>{
  state.role='artist-one';state.uploaded=[];
  const created=await invoke('POST','/storage/uploads/request-url',{body:{name:'track.mp3',size:3,contentType:'audio/mpeg'}});
  assert.equal(created.code,200);assert.equal(created.body.uploadURL,'/api/storage/uploads/send');
  state.role='artist-two';
  const refused=await invoke('PUT','/storage/uploads/send',{body:Buffer.from('abc'),headers:{'content-type':'audio/mpeg','x-upload-ticket':created.body.token}});
  assert.equal(refused.code,400);assert.equal(state.uploaded.length,0);
  state.role='artist-one';
  const sent=await invoke('PUT','/storage/uploads/send',{body:Buffer.from('abc'),headers:{'content-type':'audio/mpeg','x-upload-ticket':created.body.token}});
  assert.equal(sent.code,201);assert.equal(state.uploaded[0].path,created.body.objectPath);
  assert.equal((await invoke('POST','/storage/uploads/complete',{body:{objectPath:created.body.objectPath,uploadTicket:created.body.token}})).code,200);
  state.role='artist-two';
  assert.equal((await invoke('POST','/storage/uploads/complete',{body:{objectPath:created.body.objectPath,uploadTicket:created.body.token}})).code,403);
});
test('private media is denied to visitors and other artists, and permitted for owner or approved public work',async()=>{
  const path=uploadObjectPath('artist-one',randomUUID(),key);
  const params={path:path.slice('/objects/'.length).split('/')};
  state.published=false;state.downloads=0;state.role=null;
  assert.equal((await invoke('GET','/storage/objects/*path',{params})).code,403);
  state.role='artist-two';assert.equal((await invoke('GET','/storage/objects/*path',{params})).code,403);
  assert.equal(state.downloads,0);
  state.role='artist-one';assert.equal((await invoke('GET','/storage/objects/*path',{params})).code,200);
  state.role=null;state.published=true;
  const publicResult=await invoke('GET','/storage/objects/*path',{params});
  assert.equal(publicResult.code,200);assert.equal(publicResult.headers['x-content-type-options'],'nosniff');
  assert.equal(state.downloads,2);
});
