import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import test from 'node:test';

const state = { routes: [], role: 'visitor', calls: 0, updates: [], rows: [{id: 3}], offset: null };
globalThis.__contentTest = state;
const data = source => 'data:text/javascript,' + encodeURIComponent(source);
const stubs = {
  express: data(`export function Router() { const routes = globalThis.__contentTest.routes; return { get(path,...handlers) { routes.push({method:'GET',path,handlers}); }, patch(path,...handlers) { routes.push({method:'PATCH',path,handlers}); } }; }`),
  'drizzle-orm': data(`export function eq(column,value) { return {column,value}; }`),
  '@workspace/db': data(`
    export const artistsTable = new Proxy({}, {get(_,key) { return 'artists.'+key; }});
    export const pressRequestsTable = new Proxy({}, {get(_,key) { return 'press.'+key; }});
    export const db = {
      select() { const s=globalThis.__contentTest; s.calls++; return {from() { return {orderBy() { return {limit() { return {async offset(value) {s.offset=value; return s.rows;} };} };} };} }; },
      update() { const s=globalThis.__contentTest; s.calls++; return {set(value) {s.updates.push(value); return {where() {return {async returning() {return s.rows;} };} };} }; }
    };
  `),
  '@clerk/express': data(`
    export function getAuth() {return {userId:globalThis.__contentTest.role==='visitor'?null:'user'};}
    export const clerkClient={users:{async getUser() {return {primaryEmailAddressId:'p',emailAddresses:[{id:'p',emailAddress:globalThis.__contentTest.role==='admin'?'indamorarecords@gmail.com':'artist@example.test',verification:{status:'verified'}}]};}}};
  `),
};
registerHooks({resolve(specifier, context, nextResolve) {
  if (stubs[specifier]) return {url:stubs[specifier],shortCircuit:true};
  if (specifier === '../middlewares/auth') return {url:new URL('../artifacts/api-server/src/middlewares/auth.ts',import.meta.url).href,shortCircuit:true};
  return nextResolve(specifier,context);
}});
await import('../artifacts/api-server/src/routes/admin-content.ts');

async function invoke(method,path,body={},id='3',query={}) {
  const route=state.routes.find(r=>r.method===method && r.path===path);
  const req={body,params:{id},query};
  const res={code:200,body:null,headers:{},set(k,v){this.headers[k]=v;return this;},status(c){this.code=c;return this;},json(v){this.body=v;return this;}};
  for (const handler of route.handlers) {
    let next=false;
    await handler(req,res,error=>{assert.equal(error,undefined);next=true;});
    if (!next) break;
  }
  return res;
}
test('every content administration route rejects visitors and artists before database access',async()=>{
  for (const role of ['visitor','artist']) {
    state.role=role;state.calls=0;
    for (const route of state.routes) {
      const res=await invoke(route.method,route.path,{status:'approved'});
      assert.equal(res.code,role==='visitor'?401:403);
    }
    assert.equal(state.calls,0);
  }
});
test('only verified administrator can publish and unpublish; ignores ownership injection',async()=>{
  state.role='admin';state.rows=[{id:3}];state.updates=[];
  const result=await invoke('PATCH','/admin/profiles/:id/status',{status:'approved',ownerId:'attacker',isPublished:'false'});
  assert.equal(result.code,200);assert.equal(result.headers['Cache-Control'],'no-store');
  assert.deepEqual(state.updates.at(-1),{profileStatus:'approved',isPublished:'true'});
  await invoke('PATCH','/admin/profiles/:id/status',{status:'rejected'});
  assert.deepEqual(state.updates.at(-1),{profileStatus:'rejected',isPublished:'false'});
});
test('invalid statuses, identifiers and pages cannot mutate or query data',async()=>{
  state.role='admin';state.calls=0;
  assert.equal((await invoke('PATCH','/admin/profiles/:id/status',{status:'admin'})).code,400);
  assert.equal((await invoke('PATCH','/admin/profiles/:id/status',{status:'approved'},'-1')).code,400);
  assert.equal((await invoke('PATCH','/admin/press-requests/:id/status',{status:'approved'})).code,400);
  assert.equal((await invoke('GET','/admin/profiles',{},'3',{offset:-1})).code,400);
  assert.equal(state.calls,0);
});
test('pagination is bounded and unknown records return 404; press status is allowlisted',async()=>{
  state.role='admin';state.rows=Array.from({length:26},(_,id)=>({id}));
  const page=await invoke('GET','/admin/profiles',{},'3',{offset:25});
  assert.equal(page.body.profiles.length,25);assert.equal(page.body.hasMore,true);assert.equal(state.offset,25);
  state.rows=[];
  assert.equal((await invoke('PATCH','/admin/profiles/:id/status',{status:'approved'})).code,404);
  state.rows=[{id:3}];
  assert.equal((await invoke('PATCH','/admin/press-requests/:id/status',{status:'handled'})).code,200);
  assert.deepEqual(state.updates.at(-1),{status:'handled'});
});
