import express, { Router, type IRouter } from 'express';
import { Readable } from 'node:stream';
import { getAuth } from '@clerk/express';
import { and, eq, or } from 'drizzle-orm';
import { db, worksTable } from '@workspace/db';
import { RequestUploadUrlBody, CompleteUploadBody } from '@workspace/api-zod';
import { requireAuth, isAdminUser } from '../middlewares/auth';
import { createUploadTicket, verifyUploadTicket } from '../lib/upload-ticket';
import { isObjectOwner, storageObjectName, uploadObjectPath } from '../lib/media-path';
import { createLargeUpload, downloadObject, mediaConfig, objectMetadata, putObject } from '../lib/supabase-media';

const router: IRouter = Router();
router.post('/storage/uploads/request-url', requireAuth, async (req, res) => {
  const input = RequestUploadUrlBody.safeParse(req.body);
  if (!input.success) { res.status(400).json({ error: 'Métadonnées invalides.' }); return; }
  try {
    const { secret } = mediaConfig();
    const ticket = createUploadTicket({ ownerId: req.clerkUserId!, mime: input.data.contentType, size: input.data.size }, secret);
    const objectPath = uploadObjectPath(req.clerkUserId!, ticket.id, secret);
    const resumable = input.data.size > 6 * 1024 * 1024 ? await createLargeUpload(objectPath, input.data.size) : undefined;
    res.set('Cache-Control', 'no-store').json({ uploadURL: '/api/storage/uploads/send', objectPath, token: ticket.token, resumable });
  } catch { res.status(400).json({ error: 'Format non accepté, fichier supérieur à 50 Mo ou stockage indisponible.' }); }
});

router.put('/storage/uploads/send', requireAuth, express.raw({ type: () => true, limit: '6mb' }), async (req, res) => {
  try {
    const { secret } = mediaConfig();
    const ticket = verifyUploadTicket(req.get('x-upload-ticket') ?? '', req.clerkUserId!, secret);
    if (!ticket || ticket.size > 6 * 1024 * 1024 || !Buffer.isBuffer(req.body) || req.body.length !== ticket.size || req.get('content-type') !== ticket.mime) {
      res.status(400).json({ error: 'Envoi invalide ou expiré.' }); return;
    }
    await putObject(uploadObjectPath(req.clerkUserId!, ticket.id, secret), req.body, ticket.mime);
    res.set('Cache-Control', 'no-store').status(201).json({ ok: true });
  } catch { res.status(503).json({ error: 'Le stockage est temporairement indisponible.' }); }
});

router.post('/storage/uploads/complete', requireAuth, async (req, res) => {
  const input = CompleteUploadBody.safeParse(req.body);
  if (!input.success) { res.status(400).json({ error: 'Chemin invalide.' }); return; }
  try {
    const { secret } = mediaConfig();
    if (!isObjectOwner(input.data.objectPath, req.clerkUserId!, secret)) { res.status(403).json({ error: 'Accès refusé.' }); return; }
    const ticket = verifyUploadTicket(req.body?.uploadTicket ?? '', req.clerkUserId!, secret);
    if (!ticket || uploadObjectPath(req.clerkUserId!, ticket.id, secret) !== input.data.objectPath) { res.status(403).json({ error: 'Autorisation d’envoi invalide.' }); return; }
    const metadata = await objectMetadata(input.data.objectPath);
    if (!metadata || metadata.size !== ticket.size || metadata.mime !== ticket.mime) { res.status(400).json({ error: 'Fichier introuvable ou incomplet.' }); return; }
    res.set('Cache-Control', 'no-store').json({ objectPath: input.data.objectPath });
  } catch { res.status(503).json({ error: 'Le stockage est temporairement indisponible.' }); }
});

router.get('/storage/objects/*path', async (req, res) => {
  try {
    const raw = req.params.path;
    const path = `/objects/${Array.isArray(raw) ? raw.join('/') : raw}`;
    if (!storageObjectName(path)) { res.status(404).json({ error: 'Fichier introuvable.' }); return; }
    const { secret } = mediaConfig();
    const userId = getAuth(req).userId;
    const owned = userId ? isObjectOwner(path, userId, secret) : false;
    const admin = userId && !owned ? await isAdminUser(userId) : false;
    const [published] = owned || admin ? [] : await db.select({ id: worksTable.id }).from(worksTable)
      .where(and(eq(worksTable.access, 'free'), or(eq(worksTable.mediaObjectPath, path), eq(worksTable.coverObjectPath, path)))).limit(1);
    if (!owned && !admin && !published) { res.status(403).json({ error: 'Accès refusé.' }); return; }
    const result = await downloadObject(path, req.headers.range);
    if (!result.ok && result.status !== 206) { res.status(result.status === 404 ? 404 : 503).json({ error: 'Fichier indisponible.' }); return; }
    res.status(result.status).set('X-Content-Type-Options', 'nosniff')
      .set('Cache-Control', published ? 'public, max-age=60' : 'private, no-store');
    for (const header of ['content-type', 'content-length', 'content-range', 'accept-ranges']) {
      const value = result.headers.get(header); if (value) res.set(header, value);
    }
    if (result.body) Readable.fromWeb(result.body as ReadableStream<Uint8Array>).pipe(res); else res.end();
  } catch { res.status(503).json({ error: 'Le stockage est temporairement indisponible.' }); }
});

export default router;
