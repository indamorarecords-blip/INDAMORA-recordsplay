import { Router, type IRouter } from "express";
import adminUsersRouter from "./admin-users";
import adminContentRouter from "./admin-content";
import healthRouter from "./health";
import playStatsRouter from "./play-stats";
import indamoraRouter from "./indamora";
import storageRouter from "./storage";
import supabaseStorageRouter from "./supabase-storage";

const router: IRouter = Router();

router.use(adminUsersRouter);
router.use(adminContentRouter);
router.use(healthRouter);
router.use(playStatsRouter);
router.use(indamoraRouter);
router.use(process.env.MEDIA_STORAGE_PROVIDER === 'supabase' ? supabaseStorageRouter : storageRouter);

export default router;
