import { Router, type IRouter } from 'express';
import { pool } from '@workspace/db';
import { requireAdmin } from '../middlewares/auth';

const router: IRouter = Router();

// Public write-only event; response never contains a count or user data.
router.post('/works/:id/play', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) { res.sendStatus(400); return; }
  await pool.query(`
    INSERT INTO public.work_play_counts (work_id, plays)
    SELECT id, 1 FROM public.works
    WHERE id = $1 AND access = 'free' AND media_object_path IS NOT NULL
    ON CONFLICT (work_id) DO UPDATE SET plays = public.work_play_counts.plays + 1
  `, [id]);
  res.set('Cache-Control', 'no-store').sendStatus(204);
});

router.get('/admin/play-stats', requireAdmin, async (_req, res) => {
  const result = await pool.query<{ title: string; artist: string; plays: string }>(`
    SELECT w.title, w.artist, c.plays::text AS plays
    FROM public.work_play_counts c JOIN public.works w ON w.id = c.work_id
    ORDER BY c.plays DESC, w.id ASC LIMIT 50
  `);
  res.set('Cache-Control', 'no-store').json({ works: result.rows });
});

export default router;
