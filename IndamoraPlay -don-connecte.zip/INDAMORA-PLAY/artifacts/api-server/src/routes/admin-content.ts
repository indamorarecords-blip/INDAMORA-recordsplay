import { Router, type IRouter } from 'express';
import { eq } from 'drizzle-orm';
import { db, artistsTable, pressRequestsTable } from '@workspace/db';
import { requireAdmin } from '../middlewares/auth';

const router: IRouter = Router();

function page(query: Record<string, unknown>) {
  const offset = query.offset === undefined ? 0 : Number(query.offset);
  return Number.isSafeInteger(offset) && offset >= 0 ? offset : null;
}

router.get('/admin/profiles', requireAdmin, async (req, res): Promise<void> => {
  const offset = page(req.query);
  if (offset === null) { res.status(400).json({ error: 'Page invalide.' }); return; }
  const rows = await db.select({
    id: artistsTable.id, name: artistsTable.name, category: artistsTable.category,
    bio: artistsTable.bio, location: artistsTable.location,
    profileStatus: artistsTable.profileStatus, isPublished: artistsTable.isPublished,
  }).from(artistsTable).orderBy(artistsTable.id).limit(26).offset(offset);
  res.json({ profiles: rows.slice(0, 25), hasMore: rows.length > 25 });
});

router.patch('/admin/profiles/:id/status', requireAdmin, async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  const status: unknown = req.body?.status;
  if (!Number.isSafeInteger(id) || id <= 0 ||
      (status !== 'approved' && status !== 'rejected' && status !== 'pending')) {
    res.status(400).json({ error: 'Profil ou statut invalide.' }); return;
  }
  // Publication follows moderation; client-supplied ownership and flags are ignored.
  const [profile] = await db.update(artistsTable).set({
    profileStatus: status, isPublished: status === 'approved' ? 'true' : 'false',
  }).where(eq(artistsTable.id, id)).returning({ id: artistsTable.id });
  if (!profile) { res.status(404).json({ error: 'Profil introuvable.' }); return; }
  res.json({ id: profile.id, status });
});

router.get('/admin/press-requests', requireAdmin, async (req, res): Promise<void> => {
  const offset = page(req.query);
  if (offset === null) { res.status(400).json({ error: 'Page invalide.' }); return; }
  const rows = await db.select().from(pressRequestsTable)
    .orderBy(pressRequestsTable.id).limit(26).offset(offset);
  res.json({ requests: rows.slice(0, 25), hasMore: rows.length > 25 });
});

router.patch('/admin/press-requests/:id/status', requireAdmin, async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  const status: unknown = req.body?.status;
  if (!Number.isSafeInteger(id) || id <= 0 ||
      (status !== 'handled' && status !== 'archived' && status !== 'pending')) {
    res.status(400).json({ error: 'Demande ou statut invalide.' }); return;
  }
  const [request] = await db.update(pressRequestsTable).set({ status })
    .where(eq(pressRequestsTable.id, id)).returning({ id: pressRequestsTable.id });
  if (!request) { res.status(404).json({ error: 'Demande introuvable.' }); return; }
  res.json({ id: request.id, status });
});

export default router;
