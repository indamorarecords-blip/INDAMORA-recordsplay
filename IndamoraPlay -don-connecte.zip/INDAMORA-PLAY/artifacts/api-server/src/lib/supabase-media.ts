import { pool } from '@workspace/db';
import { storageObjectName } from './media-path';

export function mediaConfig() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const bucket = process.env.SUPABASE_MEDIA_BUCKET ?? 'indamora-media';
  const secret = process.env.UPLOAD_SIGNING_SECRET;
  if (!url || !key || !secret || Buffer.byteLength(secret, 'utf8') < 32 || !/^[a-z0-9][a-z0-9-]{1,62}$/.test(bucket)) throw new Error('Media configuration missing');
  let base: URL;
  try { base = new URL(url); } catch { throw new Error('Media configuration invalid'); }
  if (base.protocol !== 'https:' || base.username || base.password || base.pathname !== '/' || base.search || base.hash) throw new Error('Media configuration invalid');
  return { base: base.origin, key, bucket, secret };
}

export async function objectMetadata(path: string) {
  const { bucket } = mediaConfig();
  const name = storageObjectName(path);
  if (!name) return null;
  // Read Storage metadata only; never update the Storage schema directly.
  const result = await pool.query<{ mime: string; size: string }>(
    `SELECT metadata->>'mimetype' AS mime, metadata->>'size' AS size FROM storage.objects WHERE bucket_id=$1 AND name=$2 LIMIT 1`,
    [bucket, name],
  );
  const row = result.rows[0];
  if (!row) return null;
  return { mime: row.mime, size: Number(row.size) };
}

function objectUrl(path: string, authenticated: boolean) {
  const { base, bucket } = mediaConfig();
  const name = storageObjectName(path);
  if (!name) throw new Error('Invalid media path');
  return `${base}/storage/v1/object/${authenticated ? 'authenticated/' : ''}${bucket}/${name}`;
}

async function assertPrivateBucket(expectedSize: number) {
  const { key, base, bucket } = mediaConfig();
  const info = await fetch(`${base}/storage/v1/bucket/${bucket}`, {
    redirect: 'error', headers: { Authorization: `Bearer ${key}`, apikey: key },
  });
  if (!info.ok) throw new Error('Storage bucket unavailable');
  const bucketInfo: unknown = await info.json();
  if (!bucketInfo || typeof bucketInfo !== 'object' ||
      (bucketInfo as { public?: unknown }).public !== false ||
      (bucketInfo as { id?: unknown }).id !== bucket) throw new Error('Storage bucket must be private');
  const limit = Number((bucketInfo as { file_size_limit?: unknown }).file_size_limit);
  if (!Number.isSafeInteger(limit) || limit < expectedSize || limit > 50 * 1024 * 1024) throw new Error('Storage bucket size limit must be configured');
}

export async function putObject(path: string, data: Buffer, mime: string) {
  const { key } = mediaConfig();
  await assertPrivateBucket(data.length);
  const response = await fetch(objectUrl(path, false), {
    method: 'POST', redirect: 'error', headers: { Authorization: `Bearer ${key}`, apikey: key, 'Content-Type': mime, 'x-upsert': 'false' },
    body: new Uint8Array(data),
  });
  if (!response.ok) throw new Error('Storage upload failed');
}

export async function createLargeUpload(path: string, expectedSize: number) {
  const { key, base, bucket } = mediaConfig();
  const name = storageObjectName(path);
  if (!name) throw new Error('Invalid media path');
  await assertPrivateBucket(expectedSize);
  const response = await fetch(`${base}/storage/v1/object/upload/sign/${bucket}/${name}`, {
    method: 'POST', redirect: 'error', headers: { Authorization: `Bearer ${key}`, apikey: key, 'Content-Type': 'application/json' }, body: '{}',
  });
  if (!response.ok) throw new Error('Cannot prepare upload');
  const body: unknown = await response.json();
  if (!body || typeof body !== 'object' || typeof (body as { url?: unknown }).url !== 'string') throw new Error('Invalid upload authorization');
  const signed = new URL((body as { url: string }).url, `${base}/storage/v1`);
  if (signed.origin !== base) throw new Error('Invalid upload authorization');
  const token = signed.searchParams.get('token');
  if (!token || token.length > 8192) throw new Error('Invalid upload authorization');
  const host = new URL(base).hostname;
  if (!/^[a-z0-9-]+\.supabase\.co$/.test(host)) throw new Error('Direct Storage hostname unavailable');
  const endpoint = `https://${host.replace(/\.supabase\.co$/, '.storage.supabase.co')}/storage/v1/upload/resumable`;
  return { endpoint, token, bucket, objectName: name };
}

export async function downloadObject(path: string, range?: string) {
  const { key } = mediaConfig();
  const headers: Record<string, string> = { Authorization: `Bearer ${key}`, apikey: key };
  if (range && /^bytes=\d*-\d*$/.test(range)) headers.Range = range;
  return fetch(objectUrl(path, true), { redirect: 'error', headers });
}
