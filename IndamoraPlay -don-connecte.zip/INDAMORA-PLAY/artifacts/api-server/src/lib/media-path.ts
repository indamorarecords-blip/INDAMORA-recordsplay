import { createHmac, timingSafeEqual } from 'node:crypto';

const PATH = /^\/objects\/uploads\/([0-9a-f]{64})\/([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})$/;
function ownerHash(ownerId: string, secret: string): string {
  return createHmac('sha256', secret).update(ownerId, 'utf8').digest('hex');
}
export function uploadObjectPath(ownerId: string, id: string, secret: string): string {
  const path = `/objects/uploads/${ownerHash(ownerId, secret)}/${id}`;
  if (!PATH.test(path)) throw new Error('Invalid object identifier');
  return path;
}
export function storageObjectName(path: string): string | null {
  return PATH.test(path) ? path.slice('/objects/'.length) : null;
}
export function isObjectOwner(path: string, ownerId: string, secret: string): boolean {
  const match = PATH.exec(path);
  if (!match || !ownerId || Buffer.byteLength(secret, 'utf8') < 32) return false;
  const actual = Buffer.from(match[1], 'hex');
  const expected = Buffer.from(ownerHash(ownerId, secret), 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
