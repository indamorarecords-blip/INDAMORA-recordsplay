/** The frontend and API share one origin; do not reflect untrusted origins. */
export function allowedOrigin(origin: string | undefined, host: string | undefined, production: boolean): boolean {
  if (!origin || !host) return false;
  try {
    const parsed = new URL(origin);
    return (production ? parsed.protocol === 'https:' : ['http:', 'https:'].includes(parsed.protocol)) &&
      parsed.host.toLowerCase() === host.toLowerCase() && parsed.origin === origin && !parsed.username && !parsed.password;
  } catch { return false; }
}
