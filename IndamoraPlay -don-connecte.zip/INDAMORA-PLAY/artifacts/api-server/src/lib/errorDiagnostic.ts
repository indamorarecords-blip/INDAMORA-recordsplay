// Log only allowlisted codes. Database error messages can contain user data.
export function errorDiagnostic(error: unknown): { code: string; category: string } {
  const categories: Record<string, string> = {
    '28P01': 'database_authentication', '28000': 'database_authentication',
    '42501': 'database_permission', '42P01': 'database_missing_table',
    '42703': 'database_missing_column', '53300': 'database_connection_limit',
    'ECONNREFUSED': 'database_network', 'ENOTFOUND': 'database_dns',
    'ETIMEDOUT': 'database_timeout', 'ENETUNREACH': 'database_network',
    'SELF_SIGNED_CERT_IN_CHAIN': 'database_tls',
    'DEPTH_ZERO_SELF_SIGNED_CERT': 'database_tls',
    'UNABLE_TO_VERIFY_LEAF_SIGNATURE': 'database_tls',
    'ERR_TLS_CERT_ALTNAME_INVALID': 'database_tls',
    'CERT_HAS_EXPIRED': 'database_tls',
  };
  const seen = new Set<unknown>();
  let current = error;
  while (current && typeof current === 'object' && !seen.has(current)) {
    seen.add(current);
    const entry = current as { code?: unknown; cause?: unknown };
    if (typeof entry.code === 'string' && Object.hasOwn(categories, entry.code)) {
      return { code: entry.code, category: categories[entry.code]! };
    }
    current = entry.cause;
  }
  return { code: 'UNKNOWN', category: 'server_error' };
}
