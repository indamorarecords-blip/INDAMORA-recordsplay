type UploadDetails = { endpoint: string; token: string; bucket: string; objectName: string };
const CHUNK = 6 * 1024 * 1024;
const VERSION = '1.0.0';

/** Retry a bounded number of chunks during the current upload session. */
export async function resumableUpload(file: Blob, details: UploadDetails, onProgress: (value: number) => void) {
  const endpoint = new URL(details.endpoint);
  if (endpoint.protocol !== 'https:' || !/^[a-z0-9-]+\.storage\.supabase\.co$/.test(endpoint.hostname) || endpoint.pathname !== '/storage/v1/upload/resumable' || endpoint.search || endpoint.hash || !details.token) {
    throw new Error('Adresse de stockage invalide.');
  }
  const authorization = { 'Tus-Resumable': VERSION, 'x-signature': details.token };
  const metadata = [['bucketName', details.bucket], ['objectName', details.objectName], ['contentType', file.type], ['cacheControl', '0']]
    .map(([name, value]) => `${name} ${btoa(value)}`).join(',');
  const created = await fetch(endpoint.href, { method: 'POST', redirect: 'error', headers: { ...authorization, 'Upload-Length': String(file.size), 'Upload-Metadata': metadata } });
  if (!created.ok) throw new Error('Impossible de préparer l’envoi du fichier.');
  const location = created.headers.get('Location');
  if (!location) throw new Error('Le service de stockage n’a pas répondu correctement.');
  const uploadUrl = new URL(location, endpoint);
  if (uploadUrl.origin !== endpoint.origin || !uploadUrl.pathname.startsWith('/storage/v1/upload/resumable/')) throw new Error('Adresse de reprise invalide.');

  let offset = 0;
  while (offset < file.size) {
    let end = Math.min(offset + CHUNK, file.size);
    let done = false;
    for (let attempt = 0; attempt < 4 && !done; attempt++) {
      try {
        const response = await fetch(uploadUrl.href, { method: 'PATCH', redirect: 'error', headers: {
          ...authorization, 'Content-Type': 'application/offset+octet-stream', 'Upload-Offset': String(offset),
        }, body: file.slice(offset, end) });
        if (!response.ok) throw new Error('Upload interrupted');
        const next = Number(response.headers.get('Upload-Offset'));
        if (!Number.isSafeInteger(next) || next !== end) throw new Error('Invalid upload offset');
        offset = next; done = true;
      } catch {
        if (attempt === 3) throw new Error('L’envoi a été interrompu. Réessaie avec une connexion stable.');
        await new Promise(resolve => setTimeout(resolve, 500 * (attempt + 1)));
        try {
          const head = await fetch(uploadUrl.href, { method: 'HEAD', redirect: 'error', headers: authorization });
          const raw = head.headers.get('Upload-Offset');
          const resumed = raw === null ? NaN : Number(raw);
          if (!head.ok || !Number.isSafeInteger(resumed) || resumed < offset || resumed > end) throw new Error('Invalid upload offset');
          offset = resumed;
          if (offset === end) done = true;
          else end = Math.min(offset + CHUNK, file.size);
        } catch {
          // The next attempt retries from the last confirmed offset.
        }
      }
    }
    onProgress(Math.round(offset / file.size * 100));
  }
}
