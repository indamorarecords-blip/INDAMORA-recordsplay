import { useState } from 'react';
import { useUser } from '@clerk/react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { getGetArtistsQueryKey } from '@workspace/api-client-react';

type Profile = { id: number; name: string; category: string; bio: string; location: string; profileStatus: string; isPublished: string };
type PressRequest = { id: number; name: string; organization: string; email: string; subject: string; message: string; status: string; createdAt: string };

async function request<T>(url: string, status?: string): Promise<T> {
  const response = await fetch(url, {
    credentials: 'include', cache: 'no-store',
    ...(status ? { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) } : {}),
  });
  if (!response.ok) throw new Error('L’opération n’a pas pu aboutir.');
  return response.json() as Promise<T>;
}

export function AdminContent() {
  const { user, isSignedIn } = useUser();
  const client = useQueryClient();
  const [profileOffset, setProfileOffset] = useState(0);
  const [pressOffset, setPressOffset] = useState(0);
  // This component is mounted only after the server has confirmed administrator access.
  const profiles = useQuery({
    queryKey: ['admin-profiles', user?.id, profileOffset], enabled: Boolean(isSignedIn), retry: false,
    queryFn: () => request<{ profiles: Profile[]; hasMore: boolean }>(`/api/admin/profiles?offset=${profileOffset}`),
  });
  const press = useQuery({
    queryKey: ['admin-press', user?.id, pressOffset], enabled: Boolean(isSignedIn), retry: false,
    queryFn: () => request<{ requests: PressRequest[]; hasMore: boolean }>(`/api/admin/press-requests?offset=${pressOffset}`),
  });
  const change = useMutation({
    mutationFn: ({ path, status }: { path: string; status: string }) => request(path, status),
    onSuccess: async () => {
      await Promise.all([
        client.invalidateQueries({ queryKey: ['admin-profiles', user?.id] }),
        client.invalidateQueries({ queryKey: ['admin-press', user?.id] }),
        client.invalidateQueries({ queryKey: getGetArtistsQueryKey() }),
      ]);
    },
  });
  const buttonClass = 'rounded-full border border-border px-4 py-2 text-sm font-bold disabled:opacity-40';
  function actions(path: string, options: [string, string][]) {
    return <div className="mt-4 flex flex-wrap gap-2">{options.map(([status, label]) => <button key={status} type="button" className={buttonClass} disabled={change.isPending} onClick={() => change.mutate({ path, status })}>{label}</button>)}</div>;
  }
  function pagination(offset: number, setOffset: (offset: number) => void, more: boolean, busy: boolean, label: string) {
    return <nav aria-label={label} className="mt-4 flex justify-between gap-3"><button type="button" className={buttonClass} disabled={offset === 0 || busy} onClick={() => setOffset(Math.max(0, offset - 25))}>Précédent</button><button type="button" className={buttonClass} disabled={!more || busy} onClick={() => setOffset(offset + 25)}>Suivant</button></nav>;
  }
  return <div className="space-y-12">
    {change.isError && <p role="alert" className="rounded-xl border border-destructive p-4">La modification n’a pas été enregistrée. Réessayez.</p>}
    {change.isSuccess && <p role="status" className="text-sm font-bold text-secondary">Modification enregistrée.</p>}
    <section aria-labelledby="admin-profiles-title">
      <h2 id="admin-profiles-title" className="display text-3xl font-bold">Validation des profils</h2>
      <p className="mt-2 text-sm text-muted-foreground">Un profil validé apparaît dans le répertoire public. Le refus ou la remise en attente le retire du répertoire.</p>
      {profiles.isPending ? <p role="status" className="mt-5">Chargement des profils…</p> : profiles.isError ? <div role="alert" className="mt-5"><p>Impossible de charger les profils.</p><button type="button" className={buttonClass} onClick={() => void profiles.refetch()}>Réessayer</button></div> : <>
        {profiles.data.profiles.length === 0 && <p className="mt-5 text-muted-foreground">Aucun profil sur cette page.</p>}
        <div className="mt-5 space-y-3">{profiles.data.profiles.map(profile => <article key={profile.id} className="rounded-2xl border border-border bg-card p-5">
          <h3 className="font-bold">{profile.name}</h3><p className="text-sm text-muted-foreground">{profile.category} · {profile.location}</p>
          <p className="mt-3 whitespace-pre-wrap break-words text-sm">{profile.bio}</p>
          <p className="mt-3 text-sm font-semibold">{profile.profileStatus === 'approved' ? 'Validé' : profile.profileStatus === 'rejected' ? 'Refusé' : 'En attente'}</p>
          {actions(`/api/admin/profiles/${profile.id}/status`, [['approved', 'Valider et publier'], ['rejected', 'Refuser'], ['pending', 'Remettre en attente']])}
        </article>)}</div>
        {pagination(profileOffset, setProfileOffset, profiles.data.hasMore, profiles.isFetching, 'Pages des profils')}
      </>}
    </section>
    <section aria-labelledby="admin-press-title">
      <h2 id="admin-press-title" className="display text-3xl font-bold">Demandes presse</h2>
      {press.isPending ? <p role="status" className="mt-5">Chargement des demandes…</p> : press.isError ? <div role="alert" className="mt-5"><p>Impossible de charger les demandes presse.</p><button type="button" className={buttonClass} onClick={() => void press.refetch()}>Réessayer</button></div> : <>
        {press.data.requests.length === 0 && <p className="mt-5 text-muted-foreground">Aucune demande sur cette page.</p>}
        <div className="mt-5 space-y-3">{press.data.requests.map(item => <article key={item.id} className="rounded-2xl border border-border bg-card p-5">
          <h3 className="font-bold">{item.subject}</h3><p className="mt-1 break-words text-sm text-muted-foreground">{item.name} · {item.organization} · {item.email}</p>
          <p className="mt-3 whitespace-pre-wrap break-words">{item.message}</p><p className="mt-3 text-sm font-semibold">{item.status === 'handled' ? 'Traitée' : item.status === 'archived' ? 'Archivée' : 'En attente'}</p>
          {actions(`/api/admin/press-requests/${item.id}/status`, [['handled', 'Marquer comme traitée'], ['archived', 'Archiver'], ['pending', 'Remettre en attente']])}
        </article>)}</div>
        {pagination(pressOffset, setPressOffset, press.data.hasMore, press.isFetching, 'Pages des demandes presse')}
      </>}
    </section>
  </div>;
}
