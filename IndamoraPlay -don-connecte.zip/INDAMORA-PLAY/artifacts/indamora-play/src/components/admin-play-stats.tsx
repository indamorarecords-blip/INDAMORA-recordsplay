import { useUser } from '@clerk/react';
import { useQuery } from '@tanstack/react-query';

type Entry = { title: string; artist: string; plays: string };
export function AdminPlayStats() {
  const { user, isSignedIn } = useUser();
  const stats = useQuery({
    queryKey: ['admin-play-stats', user?.id], enabled: Boolean(isSignedIn), retry: false,
    queryFn: async () => {
      const response = await fetch('/api/admin/play-stats', { credentials: 'include', cache: 'no-store' });
      if (!response.ok) throw new Error('Chargement impossible');
      return response.json() as Promise<{ works: Entry[] }>;
    },
  });
  return <section aria-labelledby="play-stats-title" className="mt-12">
    <h2 id="play-stats-title" className="display text-3xl font-bold">Écoutes des œuvres</h2>
    <p className="mt-2 text-sm text-muted-foreground">Nombre de démarrages du lecteur, visibles uniquement par l’administration. Ils ne représentent pas des auditeurs uniques.</p>
    {stats.isPending ? <p role="status" className="mt-5">Chargement des écoutes…</p> : stats.isError ? <div role="alert" className="mt-5"><p>Impossible de charger les écoutes.</p><button type="button" className="mt-2 text-primary underline" onClick={() => void stats.refetch()}>Réessayer</button></div> : stats.data.works.length === 0 ? <p className="mt-5 text-muted-foreground">Aucune écoute enregistrée pour le moment.</p> : <div className="mt-5 space-y-3">{stats.data.works.map((work, index) => <div key={`${work.title}-${work.artist}-${index}`} className="flex items-center justify-between gap-4 rounded-2xl border border-border bg-card p-5"><div className="min-w-0"><p className="break-words font-bold">{work.title}</p><p className="text-sm text-muted-foreground">{work.artist}</p></div><p className="shrink-0 font-bold">{work.plays} écoute{work.plays === '1' ? '' : 's'}</p></div>)}</div>}
  </section>;
}
