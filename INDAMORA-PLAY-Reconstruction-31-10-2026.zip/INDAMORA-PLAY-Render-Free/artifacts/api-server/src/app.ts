import express, { type Express, type ErrorRequestHandler } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";
import router from "./routes";
import { logger } from "./lib/logger";
import { mountFrontend } from "./lib/serveFrontend";
import { errorDiagnostic } from "./lib/errorDiagnostic";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(cors({ credentials: true, origin: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  clerkMiddleware((req) => ({
    publishableKey: process.env.CLERK_PUBLISHABLE_KEY || publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

// The Replit media backend is not available on Render; fail explicitly until migrated.
if (process.env.MEDIA_STORAGE_ENABLED === "false") {
  app.use("/api/storage", (_req, res) => {
    res.status(503).json({ error: "Le stockage des médias n’est pas encore raccordé." });
  });
}
app.use("/api", router);
mountFrontend(app);

const handleError: ErrorRequestHandler = (error, req, res, next) => {
  if (res.headersSent) return next(error);
  logger.error({ diagnostic: errorDiagnostic(error), method: req.method,
    path: req.path, requestId: req.id }, "Server request failed");
  res.status(500).set("Cache-Control", "no-store")
    .json({ error: "Une erreur serveur empêche le chargement. Réessayez plus tard." });
};
app.use(handleError);

export default app;
