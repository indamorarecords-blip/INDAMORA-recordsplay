// Never include connection values in configuration errors.
export function databaseConfig(env) {
  const raw = env.DATABASE_URL;
  if (!raw?.trim()) throw new Error('DATABASE_URL est absente dans les variables du serveur.');
  const value = raw.trim();
  if (value.includes('[YOUR-PASSWORD]')) throw new Error('DATABASE_URL contient encore le mot de passe fictif de Supabase.');
  if (value.startsWith('DATABASE_URL=') || /^["']/.test(value)) {
    throw new Error('DATABASE_URL doit contenir uniquement l’adresse, sans nom de variable ni guillemets.');
  }
  let url;
  try { url = new URL(value); } catch {
    throw new Error('DATABASE_URL est mal formée. Vérifiez l’adresse et l’encodage du mot de passe dans les variables du serveur.');
  }
  if (!['postgres:', 'postgresql:'].includes(url.protocol) || !url.hostname || !url.username || !url.password || url.pathname.length < 2 || url.hash) {
    throw new Error('DATABASE_URL doit être une adresse PostgreSQL complète. Les caractères spéciaux du mot de passe doivent être encodés.');
  }
  return value;
}
